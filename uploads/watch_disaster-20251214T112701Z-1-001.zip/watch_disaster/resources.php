<?php
include('includes/config.php');
include('includes/auth_check.php');

$page_title = "Emergency Resources - Disaster Watch";

// Get user first name from session
$first_name = $_SESSION['first_name'] ?? 'User';

// Fetch Emergency Contacts from database
$contacts_query = "SELECT * FROM emergency_contacts ORDER BY priority ASC";
$contacts_result = $conn->query($contacts_query);
$contacts = $contacts_result ? $contacts_result->fetch_all(MYSQLI_ASSOC) : [];

// Fetch Evacuation Centers from database
$shelters_query = "SELECT * FROM evacuation_centers ORDER BY status, name";
$shelters_result = $conn->query($shelters_query);
$shelters = $shelters_result ? $shelters_result->fetch_all(MYSQLI_ASSOC) : [];

// Fetch Medical Facilities from database
$medical_query = "SELECT * FROM medical_facilities ORDER BY emergency_services DESC, bed_capacity DESC";
$medical_result = $conn->query($medical_query);
$medical = $medical_result ? $medical_result->fetch_all(MYSQLI_ASSOC) : [];

// If tables don't exist yet, use sample data
if (empty($contacts)) {
    $contacts = [
        [
            'id' => 1,
            'contact_type' => 'SERVICES',
            'name' => 'Emergency Services',
            'phone' => '911',
            'availability' => '24/7',
            'description' => 'General emergency number for police, fire, and medical',
            'priority' => 1
        ],
        [
            'id' => 2,
            'contact_type' => 'HOTLINE',
            'name' => 'Disaster Hotline',
            'phone' => '1-800-DISASTER',
            'availability' => '24/7',
            'description' => 'National disaster response hotline',
            'priority' => 2
        ],
        [
            'id' => 3,
            'contact_type' => 'ORGANIZATION',
            'name' => 'Red Cross',
            'phone' => '1-800-RED-CROSS',
            'availability' => '24/7',
            'description' => 'Humanitarian organization for disaster relief',
            'priority' => 3
        ],
        [
            'id' => 4,
            'contact_type' => 'GOVERNMENT',
            'name' => 'FEMA Helpline',
            'phone' => '1-800-621-3382',
            'availability' => '24/7',
            'description' => 'Federal Emergency Management Agency',
            'priority' => 4
        ]
    ];
}

if (empty($shelters)) {
    $shelters = [
        [
            'id' => 1,
            'name' => 'Central Community Center',
            'address' => '123 Main Street',
            'city' => 'Main City',
            'region' => 'Central',
            'capacity' => 500,
            'current_occupancy' => 320,
            'status' => 'OPEN',
            'contact_person' => 'John Smith',
            'contact_phone' => '555-0101',
            'facilities' => 'Food, Water, Medical Aid, Restrooms'
        ],
        [
            'id' => 2,
            'name' => 'North District Shelter',
            'address' => '456 Oak Avenue',
            'city' => 'North City',
            'region' => 'Northern',
            'capacity' => 350,
            'current_occupancy' => 350,
            'status' => 'FULL',
            'contact_person' => 'Maria Garcia',
            'contact_phone' => '555-0102',
            'facilities' => 'Food, Water, Beds'
        ],
        [
            'id' => 3,
            'name' => 'South Regional Facility',
            'address' => '789 Pine Road',
            'city' => 'South City',
            'region' => 'Southern',
            'capacity' => 600,
            'current_occupancy' => 450,
            'status' => 'OPEN',
            'contact_person' => 'Robert Chen',
            'contact_phone' => '555-0103',
            'facilities' => 'Food, Water, Medical Aid, WiFi, Charging Stations'
        ]
    ];
}

if (empty($medical)) {
    $medical = [
        [
            'id' => 1,
            'name' => 'City General Hospital',
            'type' => 'HOSPITAL',
            'address' => '123 Medical Boulevard',
            'city' => 'Main City',
            'region' => 'Central',
            'bed_capacity' => 250,
            'available_beds' => 45,
            'specialties' => 'Full Emergency Care, Surgery, ICU',
            'contact_phone' => '555-0201',
            'emergency_services' => 1,
            'trauma_center' => 1,
            'status' => 'OPERATIONAL'
        ],
        [
            'id' => 2,
            'name' => 'Regional Medical Center',
            'type' => 'HOSPITAL',
            'address' => '456 Health Avenue',
            'city' => 'North City',
            'region' => 'Northern',
            'bed_capacity' => 180,
            'available_beds' => 12,
            'specialties' => 'Trauma & Critical Care, Cardiology',
            'contact_phone' => '555-0202',
            'emergency_services' => 1,
            'trauma_center' => 1,
            'status' => 'LIMITED'
        ],
        [
            'id' => 3,
            'name' => 'Community Health Clinic',
            'type' => 'CLINIC',
            'address' => '789 Care Street',
            'city' => 'South City',
            'region' => 'Southern',
            'bed_capacity' => 50,
            'available_beds' => 25,
            'specialties' => 'Urgent Care, Primary Care',
            'contact_phone' => '555-0203',
            'emergency_services' => 1,
            'trauma_center' => 0,
            'status' => 'OPERATIONAL'
        ]
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DisasterWatch - <?php echo $page_title; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #0f172a;
            --primary-blue: #3b82f6;
            --secondary-blue: #60a5fa;
            --critical-red: #ef4444;
            --high-orange: #f97316;
            --medium-yellow: #f59e0b;
            --low-green: #10b981;
            --card-bg: #ffffff;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --border-color: #e2e8f0;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
            --radius-sm: 0.375rem;
            --radius-md: 0.5rem;
            --radius-lg: 0.75rem;
            --radius-xl: 1rem;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            --contacts-gradient: linear-gradient(135deg, #8b5cf6, #7c3aed);
            --shelters-gradient: linear-gradient(135deg, #10b981, #059669);
            --medical-gradient: linear-gradient(135deg, #3b82f6, #2563eb);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
        }

        .page-container {
            display: grid;
            grid-template-columns: 1fr;
            grid-template-rows: 72px 1fr;
            min-height: 100vh;
            gap: 0;
        }

        /* Header */
        header {
            grid-column: 1 / -1;
            background: var(--primary-dark);
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 32px;
            box-shadow: var(--shadow-lg);
            z-index: 50;
            position: relative;
            backdrop-filter: blur(10px);
        }

        header::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--critical-red), var(--primary-blue), var(--low-green));
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 16px;
            position: relative;
        }

        .logo-icon {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .logo-icon::before {
            content: '';
            position: absolute;
            width: 36px;
            height: 36px;
            background: var(--critical-red);
            border-radius: 50%;
            opacity: 0.2;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 0.2; }
            50% { transform: scale(1.1); opacity: 0.3; }
        }

        .logo i {
            font-size: 28px;
            color: white;
            position: relative;
            z-index: 1;
        }

        .logo h1 {
            font-size: 24px;
            font-weight: 800;
            background: linear-gradient(135deg, #fff 0%, #cbd5e1 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            letter-spacing: -0.5px;
        }

        .header-nav {
            display: flex;
            align-items: center;
            gap: 24px;
            flex: 1;
            margin: 0 48px;
        }

        .nav-link {
            color: #cbd5e1;
            text-decoration: none;
            font-size: 15px;
            font-weight: 500;
            padding: 10px 18px;
            border-radius: var(--radius-md);
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 10px;
            position: relative;
        }

        .nav-link:hover {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            transform: translateY(-1px);
        }

        .nav-link.active {
            color: white;
            background: rgba(59, 130, 246, 0.2);
            font-weight: 600;
        }

        .nav-link.active::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 18px;
            right: 18px;
            height: 3px;
            background: var(--primary-blue);
            border-radius: 2px;
        }

        .header-info {
            display: flex;
            align-items: center;
            gap: 32px;
        }

        .timestamp {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 14px;
            color: #94a3b8;
            padding: 8px 16px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: var(--radius-md);
            transition: var(--transition);
        }

        .timestamp:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateY(-1px);
        }

        .timestamp i {
            color: var(--medium-yellow);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 16px;
            font-size: 15px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: white;
            box-shadow: var(--shadow-md);
        }

        .logout-btn {
            color: white;
            background: linear-gradient(135deg, var(--critical-red), #dc2626);
            padding: 10px 20px;
            border-radius: var(--radius-md);
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
            border: none;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.25);
        }

        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(239, 68, 68, 0.4);
            background: linear-gradient(135deg, #dc2626, #b91c1c);
        }

        /* Main Content */
        .main-content {
            padding: 32px;
            overflow-y: auto;
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            position: relative;
        }

        .main-content::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 240px;
            background: linear-gradient(135deg, var(--primary-dark), #1e293b);
            clip-path: polygon(0 0, 100% 0, 100% 80%, 0 100%);
            z-index: 0;
        }

        .dashboard-header {
            position: relative;
            z-index: 1;
            margin-bottom: 32px;
        }

        .page-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .page-title h2 {
            font-size: 32px;
            font-weight: 800;
            color: white;
            margin: 0;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .stats-badge {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            color: white;
            padding: 12px 24px;
            border-radius: 50px;
            font-weight: 700;
            font-size: 16px;
            white-space: nowrap;
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .page-description {
            color: #cbd5e1;
            font-size: 16px;
            line-height: 1.6;
            max-width: 800px;
            margin-bottom: 32px;
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 16px;
            margin-bottom: 32px;
            flex-wrap: wrap;
            position: relative;
            z-index: 1;
        }

        .action-btn {
            padding: 16px 28px;
            border-radius: var(--radius-lg);
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 12px;
            border: none;
            position: relative;
            overflow: hidden;
        }

        .action-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .action-btn:hover::before {
            left: 100%;
        }

        .action-btn.primary {
            background: linear-gradient(135deg, var(--primary-blue), #2563eb);
            color: white;
            box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
        }

        .action-btn.primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(59, 130, 246, 0.4);
        }

        .action-btn.success {
            background: linear-gradient(135deg, var(--low-green), #059669);
            color: white;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
        }

        .action-btn.success:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.4);
        }

        .action-btn.warning {
            background: linear-gradient(135deg, var(--high-orange), #ea580c);
            color: white;
            box-shadow: 0 4px 15px rgba(249, 115, 22, 0.3);
        }

        .action-btn.warning:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(249, 115, 22, 0.4);
        }

        /* Search Box */
        .search-container {
            background: white;
            padding: 24px;
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-lg);
            margin-bottom: 32px;
            position: relative;
            z-index: 1;
            border: 1px solid var(--border-color);
        }

        .search-box {
            position: relative;
        }

        .search-box i {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-secondary);
            font-size: 18px;
        }

        .search-box input {
            width: 100%;
            padding: 16px 20px 16px 56px;
            border: 2px solid var(--border-color);
            border-radius: var(--radius-md);
            font-size: 16px;
            transition: var(--transition);
            background: white;
        }

        .search-box input:focus {
            border-color: var(--primary-blue);
            outline: none;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        /* Resource Tabs */
        .resource-tabs {
            display: flex;
            gap: 12px;
            margin-bottom: 32px;
            flex-wrap: wrap;
            position: relative;
            z-index: 1;
        }

        .tab-btn {
            padding: 16px 32px;
            background: white;
            border: 2px solid var(--border-color);
            border-radius: var(--radius-lg);
            cursor: pointer;
            font-weight: 600;
            font-size: 15px;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 12px;
            color: var(--text-secondary);
            box-shadow: var(--shadow-sm);
        }

        .tab-btn:hover {
            border-color: var(--primary-blue);
            color: var(--primary-blue);
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        .tab-btn.active {
            background: linear-gradient(135deg, var(--primary-blue), #2563eb);
            border-color: var(--primary-blue);
            color: white;
            box-shadow: 0 5px 15px rgba(59, 130, 246, 0.3);
            transform: translateY(-2px);
        }

        .tab-count {
            background: rgba(255, 255, 255, 0.2);
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 700;
        }

        .tab-btn.active .tab-count {
            background: rgba(255, 255, 255, 0.3);
        }

        /* Resources Grid */
        .resources-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
            gap: 28px;
            position: relative;
            z-index: 1;
        }

        .resource-card {
            background: white;
            border-radius: var(--radius-xl);
            box-shadow: var(--shadow-md);
            overflow: hidden;
            transition: var(--transition);
            position: relative;
            border: 1px solid var(--border-color);
        }

        .resource-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
        }

        .contacts-card::before { background: var(--contacts-gradient); }
        .shelters-card::before { background: var(--shelters-gradient); }
        .medical-card::before { background: var(--medical-gradient); }

        .resource-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-xl);
        }

        .card-header {
            padding: 28px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            position: relative;
        }

        .card-title {
            flex: 1;
        }

        .card-title h3 {
            margin: 0 0 8px;
            color: var(--primary-dark);
            font-size: 1.6em;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .card-title p {
            margin: 0;
            color: var(--text-secondary);
            font-size: 0.95em;
        }

        .card-icon {
            width: 60px;
            height: 60px;
            border-radius: var(--radius-lg);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
            flex-shrink: 0;
        }

        .contacts-card .card-icon { background: var(--contacts-gradient); }
        .shelters-card .card-icon { background: var(--shelters-gradient); }
        .medical-card .card-icon { background: var(--medical-gradient); }

        .card-content {
            padding: 0;
        }

        .resource-item {
            padding: 24px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            transition: background-color 0.2s;
        }

        .resource-item:hover {
            background-color: #f8fafc;
        }

        .resource-item:last-child {
            border-bottom: none;
        }

        .resource-info {
            flex: 1;
        }

        .resource-info h4 {
            margin: 0 0 12px;
            color: var(--primary-dark);
            font-size: 1.2em;
            font-weight: 700;
        }

        .resource-details {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .detail-item {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            color: var(--text-secondary);
            font-size: 14px;
        }

        .detail-item i {
            color: var(--primary-blue);
            margin-top: 2px;
            flex-shrink: 0;
        }

        .badge {
            display: inline-block;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-right: 8px;
            margin-bottom: 5px;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }

        .badge-primary { background: rgba(59, 130, 246, 0.1); color: var(--primary-blue); border: 1px solid rgba(59, 130, 246, 0.2); }
        .badge-success { background: rgba(16, 185, 129, 0.1); color: var(--low-green); border: 1px solid rgba(16, 185, 129, 0.2); }
        .badge-warning { background: rgba(249, 115, 22, 0.1); color: var(--high-orange); border: 1px solid rgba(249, 115, 22, 0.2); }
        .badge-danger { background: rgba(239, 68, 68, 0.1); color: var(--critical-red); border: 1px solid rgba(239, 68, 68, 0.2); }
        .badge-purple { background: rgba(139, 92, 246, 0.1); color: #7c3aed; border: 1px solid rgba(139, 92, 246, 0.2); }

        .contact-number {
            color: var(--primary-blue);
            font-weight: bold;
            font-size: 1.1em;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .capacity-bar {
            width: 120px;
            height: 10px;
            background: #e2e8f0;
            border-radius: 5px;
            overflow: hidden;
            margin: 8px 0;
        }

        .capacity-bar .fill {
            height: 100%;
            background: linear-gradient(90deg, var(--low-green), #8bc34a);
        }

        .capacity-info {
            font-size: 14px;
            color: var(--text-secondary);
            font-weight: 500;
        }

        .status-indicator {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 13px;
            font-weight: 600;
            padding: 4px 10px;
            border-radius: 20px;
        }

        .status-open { background: rgba(16, 185, 129, 0.1); color: var(--low-green); }
        .status-full { background: rgba(239, 68, 68, 0.1); color: var(--critical-red); }
        .status-closed { background: rgba(148, 163, 184, 0.1); color: #64748b; }
        .status-limited { background: rgba(249, 115, 22, 0.1); color: var(--high-orange); }
        .status-operational { background: rgba(16, 185, 129, 0.1); color: var(--low-green); }

        .call-btn {
            background: linear-gradient(135deg, var(--primary-blue), #2563eb);
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: var(--radius-md);
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
            white-space: nowrap;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.2);
        }

        .call-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.3);
        }

        .call-btn.call-disabled {
            background: #cbd5e1;
            cursor: not-allowed;
            box-shadow: none;
        }

        .call-btn.call-disabled:hover {
            transform: none;
            box-shadow: none;
        }

        .facilities-list {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            margin-top: 8px;
        }

        .facility-tag {
            background: rgba(59, 130, 246, 0.1);
            color: var(--primary-blue);
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
        }

        .no-results {
            grid-column: 1 / -1;
            text-align: center;
            padding: 80px 40px;
            background: white;
            border-radius: var(--radius-xl);
            box-shadow: var(--shadow-lg);
            position: relative;
            z-index: 1;
            margin-top: 32px;
            border: 2px dashed var(--border-color);
        }

        .no-results i {
            font-size: 64px;
            color: #cbd5e1;
            margin-bottom: 24px;
            opacity: 0.5;
        }

        .no-results h3 {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary-dark);
            margin-bottom: 12px;
        }

        .no-results p {
            font-size: 16px;
            color: var(--text-secondary);
            margin-bottom: 32px;
            max-width: 400px;
            margin-left: auto;
            margin-right: auto;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .resources-grid {
                grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            }
        }

        @media (max-width: 992px) {
            .page-container {
                grid-template-columns: 1fr;
                grid-template-rows: auto 1fr;
            }
            
            .header-nav {
                display: none;
            }
            
            .header-info {
                flex-direction: column;
                gap: 16px;
                align-items: flex-end;
            }
            
            .resources-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                padding: 24px;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .action-btn {
                width: 100%;
                justify-content: center;
            }
            
            .resource-tabs {
                flex-direction: column;
            }
            
            .tab-btn {
                width: 100%;
                justify-content: center;
            }
            
            .resource-item {
                flex-direction: column;
                gap: 20px;
            }
            
            .call-btn {
                width: 100%;
                justify-content: center;
            }
            
            .page-title {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .search-container {
                padding: 20px;
            }
            
            header {
                padding: 0 20px;
            }
        }

        @media (max-width: 480px) {
            .main-content {
                padding: 16px;
            }
            
            .card-header {
                padding: 20px;
                flex-direction: column;
                gap: 16px;
            }
            
            .card-icon {
                align-self: flex-start;
            }
            
            .resource-item {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="page-container">
        <!-- Header -->
        <header>
            <div class="logo">
                <div class="logo-icon">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <h1>DisasterWatch</h1>
            </div>
            
            <nav class="header-nav">
                <a href="dashboard.php" class="nav-link">
                    <i class="fas fa-home"></i> Dashboard
                </a>
                <a href="resources.php" class="nav-link active">
                    <i class="fas fa-hands-helping"></i> Resources
                </a>
            </nav>
            
            <div class="header-info">
                <div class="timestamp">
                    <i class="fas fa-clock"></i>
                    <span><?php echo date('n/j/Y, g:i A'); ?></span>
                </div>
                <div class="user-info">
                    <div class="user-avatar">
                        <?php echo strtoupper(substr($first_name, 0, 1)); ?>
                    </div>
                    <span>Welcome, <?php echo htmlspecialchars($first_name); ?></span>
                    <a href="logout.php" class="logout-btn">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <main class="main-content">
            <div class="dashboard-header">
                <div class="page-title">
                    <h2>
                        <i class="fas fa-hands-helping"></i>
                        Emergency Resources
                    </h2>
                    <div class="stats-badge">
                        <i class="fas fa-database"></i>
                        <?php echo count($contacts) + count($shelters) + count($medical); ?> Total Resources
                    </div>
                </div>
                
                <p class="page-description">
                    Access critical emergency contacts, evacuation shelters, and medical facilities. 
                    Search and filter resources to find what you need during a disaster situation.
                </p>
                
                <div class="action-buttons">
                    <button class="action-btn primary" onclick="downloadResources()">
                        <i class="fas fa-download"></i> Download All Resources
                    </button>
                    <button class="action-btn success" onclick="window.open('real_time_map.php', '_blank')">
                        <i class="fas fa-map-marked-alt"></i> View on Map
                    </button>
                    <button class="action-btn warning" onclick="shareResources()">
                        <i class="fas fa-share-alt"></i> Share Resources
                    </button>
                </div>
                
                <!-- Search Box -->
                <div class="search-container">
                    <div class="search-box">
                        <i class="fas fa-search"></i>
                        <input type="text" id="searchInput" placeholder="Search resources by name, location, phone, or type...">
                    </div>
                </div>
                
                <!-- Resource Type Tabs -->
                <div class="resource-tabs">
                    <button class="tab-btn active" data-tab="all">
                        <i class="fas fa-globe"></i>
                        All Resources
                        <span class="tab-count"><?php echo count($contacts) + count($shelters) + count($medical); ?></span>
                    </button>
                    <button class="tab-btn" data-tab="contacts">
                        <i class="fas fa-phone-alt"></i>
                        Emergency Contacts
                        <span class="tab-count"><?php echo count($contacts); ?></span>
                    </button>
                    <button class="tab-btn" data-tab="shelters">
                        <i class="fas fa-home"></i>
                        Evacuation Centers
                        <span class="tab-count"><?php echo count($shelters); ?></span>
                    </button>
                    <button class="tab-btn" data-tab="medical">
                        <i class="fas fa-hospital"></i>
                        Medical Facilities
                        <span class="tab-count"><?php echo count($medical); ?></span>
                    </button>
                </div>
            </div>

            <!-- Resources Grid -->
            <div class="resources-grid" id="resourcesGrid">
                <?php if (empty($contacts) && empty($shelters) && empty($medical)): ?>
                    <div class="no-results">
                        <i class="fas fa-search"></i>
                        <h3>No Resources Available</h3>
                        <p>Emergency resources are currently being updated. Please check back soon.</p>
                    </div>
                <?php else: ?>
                    <!-- Contacts Card -->
                    <div class="resource-card contacts-card">
                        <div class="card-header">
                            <div class="card-title">
                                <h3>
                                    <i class="fas fa-phone-alt"></i>
                                    Emergency Contacts
                                </h3>
                                <p>24/7 Hotlines & Support Services</p>
                            </div>
                            <div class="card-icon">
                                <i class="fas fa-phone-alt"></i>
                            </div>
                        </div>
                        <div class="card-content">
                            <?php foreach ($contacts as $contact): ?>
                                <div class="resource-item contact-item" data-search="<?php 
                                    echo strtolower($contact['name'] . ' ' . $contact['phone'] . ' ' . $contact['contact_type']);
                                ?>">
                                    <div class="resource-info">
                                        <h4><?php echo htmlspecialchars($contact['name']); ?></h4>
                                        <div class="resource-details">
                                            <div class="detail-item">
                                                <i class="fas fa-tag"></i>
                                                <span class="badge <?php echo getContactBadgeClass($contact['contact_type']); ?>">
                                                    <?php echo htmlspecialchars($contact['contact_type']); ?>
                                                </span>
                                            </div>
                                            <?php if (!empty($contact['description'])): ?>
                                                <div class="detail-item">
                                                    <i class="fas fa-info-circle"></i>
                                                    <span><?php echo htmlspecialchars($contact['description']); ?></span>
                                                </div>
                                            <?php endif; ?>
                                            <div class="detail-item">
                                                <i class="fas fa-phone"></i>
                                                <span class="contact-number">
                                                    <?php echo formatPhoneNumber($contact['phone']); ?>
                                                </span>
                                            </div>
                                            <div class="detail-item">
                                                <i class="far fa-clock"></i>
                                                <span><?php echo htmlspecialchars($contact['availability']); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                    <button class="call-btn" onclick="callNumber('<?php echo $contact['phone']; ?>')" 
                                            title="Call <?php echo htmlspecialchars($contact['name']); ?>">
                                        <i class="fas fa-phone"></i> Call Now
                                    </button>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Shelters Card -->
                    <div class="resource-card shelters-card">
                        <div class="card-header">
                            <div class="card-title">
                                <h3>
                                    <i class="fas fa-home"></i>
                                    Evacuation Centers
                                </h3>
                                <p>Safe Shelters & Emergency Housing</p>
                            </div>
                            <div class="card-icon">
                                <i class="fas fa-home"></i>
                            </div>
                        </div>
                        <div class="card-content">
                            <?php foreach ($shelters as $shelter): ?>
                                <?php 
                                $available = $shelter['capacity'] - ($shelter['current_occupancy'] ?? 0);
                                $percentage = $shelter['capacity'] > 0 ? (($shelter['current_occupancy'] ?? 0) / $shelter['capacity']) * 100 : 0;
                                $statusClass = 'status-' . strtolower($shelter['status']);
                                ?>
                                <div class="resource-item shelter-item" data-search="<?php 
                                    echo strtolower($shelter['name'] . ' ' . $shelter['address'] . ' ' . $shelter['status']);
                                ?>">
                                    <div class="resource-info">
                                        <h4><?php echo htmlspecialchars($shelter['name']); ?></h4>
                                        <div class="resource-details">
                                            <div class="detail-item">
                                                <i class="fas fa-map-marker-alt"></i>
                                                <span>
                                                    <?php echo htmlspecialchars($shelter['address']); ?>
                                                    <?php if (!empty($shelter['city'])): ?>
                                                        , <?php echo htmlspecialchars($shelter['city']); ?>
                                                    <?php endif; ?>
                                                </span>
                                            </div>
                                            <div class="detail-item">
                                                <i class="fas fa-info-circle"></i>
                                                <div>
                                                    <span class="status-indicator <?php echo $statusClass; ?>">
                                                        <i class="fas fa-circle" style="font-size: 8px;"></i>
                                                        <?php echo htmlspecialchars($shelter['status']); ?>
                                                    </span>
                                                    <span class="capacity-info">
                                                        <?php echo ($shelter['current_occupancy'] ?? 0); ?>/<?php echo $shelter['capacity']; ?> people
                                                    </span>
                                                </div>
                                            </div>
                                            <?php if (!empty($shelter['contact_phone'])): ?>
                                                <div class="detail-item">
                                                    <i class="fas fa-phone"></i>
                                                    <span><?php echo $shelter['contact_phone']; ?></span>
                                                </div>
                                            <?php endif; ?>
                                            <?php if (!empty($shelter['facilities'])): ?>
                                                <div class="detail-item">
                                                    <i class="fas fa-clipboard-list"></i>
                                                    <div class="facilities-list">
                                                        <?php 
                                                        $facilities = explode(',', $shelter['facilities']);
                                                        foreach ($facilities as $facility): 
                                                            $facility = trim($facility);
                                                            if (!empty($facility)):
                                                        ?>
                                                            <span class="facility-tag"><?php echo htmlspecialchars($facility); ?></span>
                                                        <?php endif; endforeach; ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="capacity-display">
                                        <div class="capacity-bar">
                                            <div class="fill" style="width: <?php echo min($percentage, 100); ?>%"></div>
                                        </div>
                                        <div class="capacity-info">
                                            <?php echo $available; ?> spots available
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Medical Card -->
                    <div class="resource-card medical-card">
                        <div class="card-header">
                            <div class="card-title">
                                <h3>
                                    <i class="fas fa-hospital"></i>
                                    Medical Facilities
                                </h3>
                                <p>Hospitals, Clinics & Emergency Care</p>
                            </div>
                            <div class="card-icon">
                                <i class="fas fa-hospital"></i>
                            </div>
                        </div>
                        <div class="card-content">
                            <?php foreach ($medical as $facility): ?>
                                <div class="resource-item medical-item" data-search="<?php 
                                    echo strtolower($facility['name'] . ' ' . $facility['type'] . ' ' . $facility['specialties']);
                                ?>">
                                    <div class="resource-info">
                                        <h4><?php echo htmlspecialchars($facility['name']); ?></h4>
                                        <div class="resource-details">
                                            <div class="detail-item">
                                                <i class="fas fa-tag"></i>
                                                <span class="badge <?php echo getMedicalBadgeClass($facility['type']); ?>">
                                                    <?php echo htmlspecialchars($facility['type']); ?>
                                                </span>
                                            </div>
                                            <div class="detail-item">
                                                <i class="fas fa-map-marker-alt"></i>
                                                <span>
                                                    <?php echo htmlspecialchars($facility['address']); ?>
                                                    <?php if (!empty($facility['city'])): ?>
                                                        , <?php echo htmlspecialchars($facility['city']); ?>
                                                    <?php endif; ?>
                                                </span>
                                            </div>
                                            <?php if (!empty($facility['specialties'])): ?>
                                                <div class="detail-item">
                                                    <i class="fas fa-stethoscope"></i>
                                                    <span><strong><?php echo htmlspecialchars($facility['specialties']); ?></strong></span>
                                                </div>
                                            <?php endif; ?>
                                            <div class="detail-item">
                                                <i class="fas fa-cogs"></i>
                                                <div>
                                                    <span class="badge <?php echo $facility['emergency_services'] ? 'badge-danger' : 'badge-primary'; ?>">
                                                        Emergency <?php echo $facility['emergency_services'] ? '✓' : '✗'; ?>
                                                    </span>
                                                    <?php if ($facility['trauma_center']): ?>
                                                        <span class="badge badge-danger">Trauma Center ✓</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="detail-item">
                                                <i class="fas fa-bed"></i>
                                                <span>
                                                    <strong><?php echo $facility['available_beds'] ?? 'N/A'; ?></strong> of 
                                                    <?php echo $facility['bed_capacity']; ?> beds available
                                                    <span class="badge badge-warning"><?php echo htmlspecialchars($facility['status']); ?></span>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <script>
        // DOM Elements
        const tabs = document.querySelectorAll('.tab-btn');
        const searchInput = document.getElementById('searchInput');
        const resourcesGrid = document.getElementById('resourcesGrid');
        let currentTab = 'all';

        // Helper functions
        function getContactBadgeClass(type) {
            switch(type) {
                case 'SERVICES': return 'badge-danger';
                case 'HOTLINE': return 'badge-warning';
                case 'ORGANIZATION': return 'badge-primary';
                case 'GOVERNMENT': return 'badge-purple';
                default: return 'badge-success';
            }
        }

        function getMedicalBadgeClass(type) {
            switch(type) {
                case 'HOSPITAL': return 'badge-danger';
                case 'TRAUMA_CENTER': return 'badge-danger';
                case 'FIELD_HOSPITAL': return 'badge-warning';
                case 'CLINIC': return 'badge-primary';
                default: return 'badge-success';
            }
        }

        function formatPhoneNumber(phone) {
            // Simple phone number formatting
            return phone.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
        }

        function callNumber(phone) {
            if (confirm(`Call ${phone}?`)) {
                window.location.href = `tel:${phone}`;
            }
        }

        function downloadResources() {
            const data = {
                contacts: <?php echo json_encode($contacts); ?>,
                shelters: <?php echo json_encode($shelters); ?>,
                medical: <?php echo json_encode($medical); ?>
            };
            
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'emergency_resources_' + new Date().toISOString().split('T')[0] + '.json';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            
            alert('Resources downloaded successfully!');
        }

        function shareResources() {
            if (navigator.share) {
                navigator.share({
                    title: 'Emergency Resources - DisasterWatch',
                    text: 'Emergency contacts, evacuation centers, and medical facilities',
                    url: window.location.href
                })
                .then(() => console.log('Resources shared successfully'))
                .catch(error => console.log('Error sharing:', error));
            } else {
                alert('Copy this link to share: ' + window.location.href);
            }
        }

        // Initialize
        document.addEventListener('DOMContentLoaded', () => {
            setupEventListeners();
            
            // Set active tab from URL parameter if exists
            const urlParams = new URLSearchParams(window.location.search);
            const tab = urlParams.get('tab');
            if (tab && ['contacts', 'shelters', 'medical', 'all'].includes(tab)) {
                switchTab(tab);
            }
        });

        function setupEventListeners() {
            // Tab switching
            tabs.forEach(tab => {
                tab.addEventListener('click', () => {
                    const tabType = tab.dataset.tab;
                    switchTab(tabType);
                    
                    // Update URL without reloading page
                    const url = new URL(window.location);
                    url.searchParams.set('tab', tabType);
                    window.history.pushState({}, '', url);
                });
            });

            // Search functionality
            searchInput.addEventListener('input', (e) => {
                filterResources(e.target.value);
            });
        }

        function switchTab(tabType) {
            tabs.forEach(tab => tab.classList.remove('active'));
            const activeTab = document.querySelector(`.tab-btn[data-tab="${tabType}"]`);
            if (activeTab) {
                activeTab.classList.add('active');
            }
            
            currentTab = tabType;
            const allCards = document.querySelectorAll('.resource-card');
            
            allCards.forEach(card => {
                if (tabType === 'all') {
                    card.style.display = 'block';
                } else {
                    if (card.classList.contains(`${tabType}-card`)) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                }
            });
            
            // Reapply search filter if there's search text
            if (searchInput.value.trim()) {
                filterResources(searchInput.value);
            }
        }

        function filterResources(searchTerm) {
            const items = document.querySelectorAll('.resource-item');
            const term = searchTerm.toLowerCase().trim();
            
            items.forEach(item => {
                if (currentTab !== 'all') {
                    const card = item.closest('.resource-card');
                    if (!card.classList.contains(`${currentTab}-card`)) {
                        item.style.display = 'none';
                        return;
                    }
                }
                
                const searchData = item.dataset.search || '';
                if (searchData.includes(term) || term === '') {
                    item.style.display = 'flex';
                    item.closest('.resource-card').style.display = 'block';
                } else {
                    item.style.display = 'none';
                    
                    // Hide entire card if all items are hidden
                    const card = item.closest('.resource-card');
                    const visibleItems = card.querySelectorAll('.resource-item[style*="display: flex"]');
                    if (visibleItems.length === 0) {
                        card.style.display = 'none';
                    }
                }
            });
        }

        // PHP helper functions (used in PHP section)
        <?php 
        function getContactBadgeClass($type) {
            switch($type) {
                case 'SERVICES': return 'badge-danger';
                case 'HOTLINE': return 'badge-warning';
                case 'ORGANIZATION': return 'badge-primary';
                case 'GOVERNMENT': return 'badge-purple';
                default: return 'badge-success';
            }
        }

        function getMedicalBadgeClass($type) {
            switch($type) {
                case 'HOSPITAL': return 'badge-danger';
                case 'TRAUMA_CENTER': return 'badge-danger';
                case 'FIELD_HOSPITAL': return 'badge-warning';
                case 'CLINIC': return 'badge-primary';
                default: return 'badge-success';
            }
        }

        function formatPhoneNumber($phone) {
            // Simple phone number formatting for PHP
            return preg_replace('/(\d{3})(\d{3})(\d{4})/', '$1-$2-$3', $phone);
        }
        ?>
    </script>
</body>
</html>