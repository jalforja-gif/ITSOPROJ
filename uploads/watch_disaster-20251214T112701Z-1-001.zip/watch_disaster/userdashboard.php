<?php
include('includes/config.php');
include('includes/auth_check.php');

$page_title = "User Dashboard - Disaster Watch";

// Get user first name from session
$first_name = $_SESSION['first_name'] ?? 'User';

// Get filter parameters - removed severity filter
$filter_type = $_GET['type'] ?? 'all';

// Build the query with filters - Users can only view active disasters
$query = "SELECT * FROM disasters WHERE status = 'active'";
$params = [];

// Apply disaster type filter
if ($filter_type !== 'all' && $filter_type !== '') {
    $query .= " AND disaster_type = ?";
    $params[] = $filter_type;
}

$query .= " ORDER BY reported_at DESC";

$stmt = $conn->prepare($query);
if ($stmt) {
    // Build bind_param string and execute
    if (!empty($params)) {
        // Determine types for bind_param
        $types = '';
        foreach ($params as $param) {
            $types .= is_int($param) ? 'i' : 's';
        }
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $disasters = $result->fetch_all(MYSQLI_ASSOC);
} else {
    $disasters = [];
}

// Get total incidents
$totalQuery = "SELECT COUNT(*) as total FROM disasters WHERE status = 'active'";
$totalStmt = $conn->prepare($totalQuery);
if ($totalStmt) {
    $totalStmt->execute();
    $totalResult = $totalStmt->get_result();
    $totalRow = $totalResult->fetch_assoc();
    $totalIncidents = $totalRow['total'] ?? 0;
} else {
    $totalIncidents = 0;
}

// Get critical alerts count
$criticalQuery = "SELECT COUNT(*) as critical FROM disasters WHERE severity = 'critical' AND status = 'active'";
$criticalStmt = $conn->prepare($criticalQuery);
if ($criticalStmt) {
    $criticalStmt->execute();
    $criticalResult = $criticalStmt->get_result();
    $criticalRow = $criticalResult->fetch_assoc();
    $criticalAlerts = $criticalRow['critical'] ?? 0;
} else {
    $criticalAlerts = 0;
}

// Get user alerts subscriptions
$userAlertsQuery = "SELECT COUNT(*) as alerts FROM alerts WHERE id = ?";
$userAlertsStmt = $conn->prepare($userAlertsQuery);
if ($userAlertsStmt) {
    $userAlertsStmt->bind_param("i", $_SESSION['id']);
    $userAlertsStmt->execute();
    $userAlertsResult = $userAlertsStmt->get_result();
    $userAlertsRow = $userAlertsResult->fetch_assoc();
    $userAlertCount = $userAlertsRow['alerts'] ?? 0;
} else {
    $userAlertCount = 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DisasterWatch - <?php echo $page_title; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Segoe+UI:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #0a1931;
            --primary-blue: #1a5fb4;
            --secondary-blue: #3584e4;
            --critical-red: #e01b24;
            --high-orange: #ff7800;
            --medium-yellow: #f6d32d;
            --low-green: #26a269;
            --card-bg: #ffffff;
            --text-primary: #333333;
            --text-secondary: #666666;
            --border-color: #e0e0e0;
            --sidebar-width: 280px;
            --header-height: 70px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: var(--text-primary);
            line-height: 1.6;
        }

        .page-container {
            display: grid;
            grid-template-columns: 280px 1fr;
            grid-template-rows: 70px 1fr;
            min-height: 100vh;
        }

        /* Header */
        header {
            grid-column: 1 / -1;
            background-color: var(--primary-dark);
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 30px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            z-index: 10;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo i {
            font-size: 28px;
            color: var(--critical-red);
        }

        .logo h1 {
            font-size: 24px;
            font-weight: 700;
        }

        .header-nav {
            display: flex;
            align-items: center;
            gap: 20px;
            flex: 1;
            margin: 0 40px;
        }

        .nav-link {
            color: white;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background-color 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }

        .nav-link.active {
            background-color: rgba(255, 255, 255, 0.15);
            font-weight: 600;
        }

        .header-info {
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .timestamp, .real-time {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            color: #ccc;
        }

        .timestamp i {
            color: var(--medium-yellow);
        }

        .real-time i {
            color: var(--low-green);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
            font-size: 14px;
        }

        .logout-btn {
            color: white;
            background-color: var(--critical-red);
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 13px;
            transition: background-color 0.3s;
            display: flex;
            align-items: center;
            gap: 5px;
            border: none;
            cursor: pointer;
        }

        .logout-btn:hover {
            background-color: #c4171f;
        }

        /* Sidebar */
        .sidebar {
            background-color: white;
            border-right: 1px solid var(--border-color);
            padding: 25px 0;
            overflow-y: auto;
        }

        .sidebar-section {
            padding: 0 25px;
            margin-bottom: 30px;
        }

        .sidebar-section h3 {
            font-size: 16px;
            font-weight: 600;
            color: var(--text-secondary);
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .user-welcome {
            background-color: #e6f0ff;
            border-left: 4px solid var(--primary-blue);
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .user-welcome h4 {
            color: var(--primary-blue);
            margin-bottom: 5px;
        }

        .user-welcome p {
            font-size: 14px;
            color: var(--text-secondary);
        }

        .alert-badge {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #ffeaea;
            border-left: 4px solid var(--critical-red);
            padding: 12px 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .alert-count {
            font-weight: 700;
            color: var(--critical-red);
            font-size: 28px;
        }

        .alert-label {
            font-size: 14px;
            color: var(--text-secondary);
        }

        .alert-icon {
            color: var(--critical-red);
            font-size: 24px;
        }

        .stats-icon {
            color: var(--primary-blue);
            font-size: 24px;
        }

        .filter-section {
            margin-bottom: 25px;
        }

        .filter-options {
            list-style: none;
        }

        .filter-options li {
            margin-bottom: 10px;
            display: flex;
            align-items: center;
        }

        .filter-options input[type="radio"] {
            margin-right: 10px;
            accent-color: var(--primary-blue);
            cursor: pointer;
        }

        .filter-options label {
            cursor: pointer;
            font-size: 15px;
            display: flex;
            align-items: center;
            width: 100%;
            padding: 5px 0;
        }

        .filter-options label:hover {
            color: var(--primary-blue);
        }

        .apply-filters-btn {
            width: 100%;
            padding: 12px;
            background-color: var(--primary-blue);
            color: white;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 0;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .apply-filters-btn:hover {
            background-color: var(--secondary-blue);
        }

        .reset-filters-btn {
            width: 100%;
            padding: 10px;
            background-color: #f5f7fa;
            color: var(--text-secondary);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 0;
            margin-bottom: 0;
        }

        .reset-filters-btn:hover {
            background-color: #e8eef7;
            color: var(--primary-blue);
        }

        /* Main Content */
        .main-content {
            padding: 30px;
            overflow-y: auto;
        }

        .dashboard-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .dashboard-title h2 {
            font-size: 28px;
            font-weight: 700;
            color: var(--primary-dark);
        }

        .incident-count {
            background-color: var(--primary-blue);
            color: white;
            padding: 8px 20px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 16px;
            white-space: nowrap;
        }

        /* User Actions Section */
        .user-actions {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .user-action-card {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border-top: 4px solid var(--primary-blue);
        }

        .user-action-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .user-action-card i {
            font-size: 36px;
            color: var(--primary-blue);
            margin-bottom: 15px;
        }

        .user-action-card h3 {
            font-size: 18px;
            color: var(--primary-dark);
            margin-bottom: 10px;
        }

        .user-action-card p {
            font-size: 14px;
            color: var(--text-secondary);
            margin-bottom: 15px;
        }

        .user-action-btn {
            background-color: var(--primary-blue);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.3s;
            width: 100%;
        }

        .user-action-btn:hover {
            background-color: var(--secondary-blue);
        }

        /* Filter Info */
        .filter-info {
            background-color: #f0f7ff;
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            border-left: 4px solid var(--primary-blue);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .filter-info span {
            font-size: 15px;
            color: var(--text-primary);
        }

        .filter-info strong {
            color: var(--primary-blue);
        }

        /* Disaster Cards */
        .disaster-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .disaster-card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            border-top: 5px solid var(--critical-red);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
        }

        .disaster-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .disaster-header {
            padding: 20px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        .disaster-type {
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .disaster-location {
            font-size: 14px;
            color: var(--text-secondary);
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .disaster-location i {
            color: var(--primary-blue);
        }

        .disaster-severity {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .severity-critical-bg {
            background-color: #ffeaea;
            color: var(--critical-red);
        }

        .severity-high-bg {
            background-color: #fff0e6;
            color: var(--high-orange);
        }

        .severity-medium-bg {
            background-color: #fff9e6;
            color: #b58b00;
        }

        .severity-low-bg {
            background-color: #e6f7ed;
            color: var(--low-green);
        }

        .disaster-details {
            padding: 20px;
        }

        .disaster-description {
            margin-bottom: 20px;
            font-size: 15px;
            color: var(--text-primary);
        }

        .disaster-stats {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
        }

        .stat-item {
            text-align: center;
        }

        .stat-value {
            font-size: 20px;
            font-weight: 700;
            color: var(--primary-dark);
        }

        .stat-label {
            font-size: 12px;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .disaster-status {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
        }

        .status-active {
            background-color: #e6f7ed;
            color: var(--low-green);
        }

        .status-warning {
            background-color: #fff0e6;
            color: var(--high-orange);
        }

        .status-monitoring {
            background-color: #e6f0ff;
            color: var(--primary-blue);
        }

        .update-time {
            font-size: 12px;
            color: var(--text-secondary);
        }

        .card-actions {
            position: absolute;
            top: 15px;
            right: 15px;
            display: flex;
            gap: 8px;
        }

        .card-action-btn {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: none;
            cursor: pointer;
            transition: all 0.3s;
            background-color: white;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .card-action-btn:hover {
            transform: scale(1.1);
        }

        .card-action-btn.info {
            color: var(--primary-blue);
        }

        .card-action-btn.alert {
            color: var(--critical-red);
        }

        .no-results {
            text-align: center;
            padding: 60px 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }

        .no-results i {
            font-size: 64px;
            color: var(--border-color);
            margin-bottom: 20px;
        }

        @media (max-width: 992px) {
            .page-container {
                grid-template-columns: 1fr;
            }
            
            .sidebar {
                display: none;
            }
            
            .header-nav {
                display: none;
            }
        }

        @media (max-width: 768px) {
            .disaster-grid {
                grid-template-columns: 1fr;
            }
            
            .user-actions {
                grid-template-columns: 1fr;
            }
            
            .header-info {
                flex-direction: column;
                gap: 10px;
                align-items: flex-end;
                font-size: 12px;
            }
            
            .dashboard-title {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <div class="page-container">
        <!-- Header -->
        <header>
            <div class="logo">
                <i class="fas fa-exclamation-triangle"></i>
                <h1>DisasterWatch</h1>
            </div>
            
            <nav class="header-nav">
                <a href="userdashboard.php" class="nav-link active">
                    <i class="fas fa-home"></i> Dashboard
                </a>
                <a href="alerts.php" class="nav-link">
                    <i class="fas fa-bell"></i> My Alerts
                </a>
                <a href="resources.php" class="nav-link">
                    <i class="fas fa-hands-helping"></i> Resources
                </a>
                <a href="profile.php" class="nav-link">
                    <i class="fas fa-user"></i> Profile
                </a>
            </nav>
            <div class="header-info">
                <div class="timestamp">
                    <i class="fas fa-clock"></i>
                    <span>Last updated: <?php echo date('n/j/Y, g:i:s A'); ?></span>
                </div>
                <div class="real-time">
                    <i class="fas fa-satellite-dish"></i>
                    <span>Real-time tracking active</span>
                </div>
                <div class="user-info">
                    <span>Welcome, <?php echo htmlspecialchars($first_name); ?></span>
                    <a href="logout.php" class="logout-btn">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </header>

        <!-- Sidebar -->
        <aside class="sidebar">
            <form id="filter-form" method="GET" action="">
                <div class="sidebar-section" style="margin-bottom: 15px;">
                    <button type="submit" class="apply-filters-btn">
                        <i class="fas fa-filter"></i> Apply Filters
                    </button>
                    <button type="button" class="reset-filters-btn" id="reset-filters">
                        <i class="fas fa-redo"></i> Reset Filters
                    </button>
                </div>

                <div class="sidebar-section">
                    <div class="user-welcome">
                        <h4>Hello, <?php echo htmlspecialchars($first_name); ?>!</h4>
                        <p>You have <?php echo $userAlertCount; ?> active alerts</p>
                    </div>
                </div>

                <div class="sidebar-section">
                    <div class="alert-badge">
                        <div>
                            <div class="alert-count"><?php echo $criticalAlerts; ?></div>
                            <div class="alert-label">Critical Alerts</div>
                        </div>
                        <i class="fas fa-bell alert-icon"></i>
                    </div>
                </div>

                <div class="sidebar-section filter-section">
                    <h3>Disaster Type</h3>
                    <ul class="filter-options">
                        <li>
                            <input type="radio" id="type-all" name="type" value="all" 
                                   <?php echo $filter_type === 'all' ? 'checked' : ''; ?>>
                            <label for="type-all">All Types</label>
                        </li>
                        <li>
                            <input type="radio" id="type-earthquake" name="type" value="earthquake"
                                   <?php echo $filter_type === 'earthquake' ? 'checked' : ''; ?>>
                            <label for="type-earthquake">Earthquake</label>
                        </li>
                        <li>
                            <input type="radio" id="type-hurricane" name="type" value="hurricane"
                                   <?php echo $filter_type === 'hurricane' ? 'checked' : ''; ?>>
                            <label for="type-hurricane">Hurricane</label>
                        </li>
                        <li>
                            <input type="radio" id="type-flood" name="type" value="flood"
                                   <?php echo $filter_type === 'flood' ? 'checked' : ''; ?>>
                            <label for="type-flood">Flood</label>
                        </li>
                        <li>
                            <input type="radio" id="type-wildfire" name="type" value="wildfire"
                                   <?php echo $filter_type === 'wildfire' ? 'checked' : ''; ?>>
                            <label for="type-wildfire">Wildfire</label>
                        </li>
                        <li>
                            <input type="radio" id="type-tsunami" name="type" value="tsunami"
                                   <?php echo $filter_type === 'tsunami' ? 'checked' : ''; ?>>
                            <label for="type-tsunami">Tsunami</label>
                        </li>
                        <li>
                            <input type="radio" id="type-tornado" name="type" value="tornado"
                                   <?php echo $filter_type === 'tornado' ? 'checked' : ''; ?>>
                            <label for="type-tornado">Tornado</label>
                        </li>
                        <li>
                            <input type="radio" id="type-volcano" name="type" value="volcano"
                                   <?php echo $filter_type === 'volcano' ? 'checked' : ''; ?>>
                            <label for="type-volcano">Volcano</label>
                        </li>
                    </ul>
                </div>

                <div class="sidebar-section">
                    <h3>Active Disasters</h3>
                    <div class="alert-badge">
                        <div>
                            <div class="alert-count"><?php echo $totalIncidents; ?></div>
                            <div class="alert-label">Worldwide</div>
                        </div>
                        <i class="fas fa-globe-americas stats-icon"></i>
                    </div>
                </div>
            </form>
        </aside>

        <main class="main-content">
            <div class="dashboard-title">
                <h2>Active Disasters Overview</h2>
                <div class="incident-count"><?php echo count($disasters); ?> Active Incidents</div>
            </div>

            <!-- User Action Cards -->
            <div class="user-actions">
                <div class="user-action-card">
                    <i class="fas fa-bell"></i>
                    <h3>Alert Preferences</h3>
                    <p>Configure how you receive emergency alerts and notifications</p>
                    <button class="user-action-btn" onclick="window.location.href='alerts.php'">Manage Alerts</button>
                </div>
                
                <div class="user-action-card">
                    <i class="fas fa-map-marked-alt"></i>
                    <h3>Live Disaster Map</h3>
                    <p>View real-time disaster locations on interactive map</p>
                    <button class="user-action-btn" onclick="window.open('real_time_map.php', '_blank')">Open Map</button>
                </div>
                
                <div class="user-action-card">
                    <i class="fas fa-user-shield"></i>
                    <h3>Safety Resources</h3>
                    <p>Access emergency preparedness guides and safety tips</p>
                    <button class="user-action-btn" onclick="window.location.href='resources.php'">View Resources</button>
                </div>
                
                <div class="user-action-card">
                    <i class="fas fa-history"></i>
                    <h3>Alert History</h3>
                    <p>Review past alerts and emergency notifications</p>
                    <button class="user-action-btn" onclick="window.location.href='alert_history.php'">View History</button>
                </div>
            </div>

            <?php if ($filter_type !== 'all'): ?>
            <div class="filter-info">
                <span>
                    Showing 
                    <strong><?php echo count($disasters); ?> disasters</strong>
                    | Type: <strong><?php echo ucfirst($filter_type); ?></strong>
                </span>
                <a href="userdashboard.php" style="color: var(--primary-blue); text-decoration: none; font-size: 14px;">
                    <i class="fas fa-times"></i> Clear filter
                </a>
            </div>
            <?php endif; ?>

            <?php if (empty($disasters)): ?>
                <div class="no-results">
                    <i class="fas fa-search"></i>
                    <h3>No active disasters found</h3>
                    <p>Currently there are no active disasters reported. Stay safe!</p>
                </div>
            <?php else: ?>
                <div class="disaster-grid">
                    <?php foreach ($disasters as $disaster): ?>
                        <?php
                        $severityClass = 'severity-' . strtolower($disaster['severity']) . '-bg';
                        $statusClass = 'status-' . strtolower($disaster['status']);
                        $reportedDate = date('n/j/Y, g:i A', strtotime($disaster['reported_at']));
                        ?>
                        
                        <div class="disaster-card" data-id="<?php echo $disaster['id']; ?>" 
                             data-severity="<?php echo strtolower($disaster['severity']); ?>">
                            
                            <div class="card-actions">
                                <button class="card-action-btn info" title="More Information">
                                    <i class="fas fa-info-circle"></i>
                                </button>
                                <button class="card-action-btn alert" title="Set Alert for this Disaster">
                                    <i class="fas fa-bell"></i>
                                </button>
                            </div>
                            
                            <div class="disaster-header">
                                <div>
                                    <div class="disaster-type"><?php echo htmlspecialchars($disaster['title']); ?></div>
                                    <div class="disaster-location">
                                        <i class="fas fa-map-marker-alt"></i>
                                        <span><?php echo htmlspecialchars($disaster['location']); ?></span>
                                    </div>
                                </div>
                                <div class="disaster-severity <?php echo $severityClass; ?>">
                                    <?php echo ucfirst($disaster['severity']); ?>
                                </div>
                            </div>
                            <div class="disaster-details">
                                <p class="disaster-description"><?php echo htmlspecialchars($disaster['description']); ?></p>
                                <div class="disaster-stats">
                                    <div class="stat-item">
                                        <div class="stat-value"><?php echo $disaster['radius_km']; ?> km</div>
                                        <div class="stat-label">Radius</div>
                                    </div>
                                    <div class="stat-item">
                                        <div class="stat-value"><?php echo $disaster['casualties'] ?: '-'; ?></div>
                                        <div class="stat-label">Casualties</div>
                                    </div>
                                </div>
                                <div class="disaster-status">
                                    <div class="status-badge <?php echo $statusClass; ?>"><?php echo ucfirst($disaster['status']); ?></div>
                                    <div class="update-time">Reported <?php echo $reportedDate; ?></div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>

    <?php include('includes/footer.php'); ?>

    <script>
        // Reset filters button
        const resetBtn = document.getElementById('reset-filters');
        if (resetBtn) {
            resetBtn.addEventListener('click', function() {
                window.location.href = 'userdashboard.php';
            });
        }

        // Color code disaster cards based on severity
        const disasterCards = document.querySelectorAll('.disaster-card');
        disasterCards.forEach(card => {
            const severity = card.getAttribute('data-severity');
            let borderColor = '#e01b24';
            
            if (severity === 'high') borderColor = '#ff7800';
            if (severity === 'medium') borderColor = '#f6d32d';
            if (severity === 'low') borderColor = '#26a269';
            
            card.style.borderTopColor = borderColor;
        });

        // Add click functionality to info buttons
        document.querySelectorAll('.card-action-btn.info').forEach(button => {
            button.addEventListener('click', function() {
                const disasterCard = this.closest('.disaster-card');
                const disasterId = disasterCard.getAttribute('data-id');
                alert('More information for disaster ID: ' + disasterId + '\nThis feature is under development.');
            });
        });

        // Add click functionality to alert buttons
        document.querySelectorAll('.card-action-btn.alert').forEach(button => {
            button.addEventListener('click', function() {
                const disasterCard = this.closest('.disaster-card');
                const disasterId = disasterCard.getAttribute('data-id');
                const disasterType = disasterCard.querySelector('.disaster-type').textContent;
                
                if (confirm('Do you want to set an alert for:\n\n' + disasterType + '?\n\nYou will receive notifications for updates.')) {
                    alert('Alert set successfully! You will now receive updates about this disaster.');
                }
            });
        });
    </script>
</body>
</html>