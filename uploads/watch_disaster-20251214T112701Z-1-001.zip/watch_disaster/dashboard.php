<?php
include('includes/config.php');
include('includes/auth_check.php');

$page_title = "Dashboard - Disaster Watch";

// Get user first name from session
$first_name = $_SESSION['first_name'] ?? 'User';

// Handle delete disaster
if (isset($_GET['delete'])) {
    $disaster_id = $_GET['delete'];
    $deleteQuery = "UPDATE disasters SET status = 'resolved' WHERE id = ?";
    $deleteStmt = $conn->prepare($deleteQuery);
    $deleteStmt->bind_param("i", $disaster_id);
    $deleteStmt->execute();
    
    header('Location: dashboard.php?message=deleted');
    exit();
}

// Handle add new disaster
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_disaster'])) {
    $disaster_type = $_POST['disaster_type'];
    $title = $_POST['title'];
    $location = $_POST['location'];
    $severity = $_POST['severity'];
    $description = $_POST['description'];
    $radius_km = $_POST['radius_km'];
    $casualties = $_POST['casualties'] ?: 0;
    $status = $_POST['status'] ?? 'active';
    
    $insertQuery = "INSERT INTO disasters (disaster_type, title, location, severity, description, radius_km, casualties, status, reported_at, created_by) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)";
    
    $insertStmt = $conn->prepare($insertQuery);
    if ($insertStmt) {
        $insertStmt->bind_param("sssssiiis", $disaster_type, $title, $location, $severity, $description, $radius_km, $casualties, $status, $_SESSION['user_id']);
        if ($insertStmt->execute()) {
            header('Location: dashboard.php?message=added');
            exit();
        }
    }
}

// Get filter parameters
$filter_type = $_GET['type'] ?? 'all';
$filter_severity = $_GET['severity'] ?? 'all';
$filter_security = $_GET['security'] ?? 'all';

// Build the query with filters
$query = "SELECT * FROM disasters WHERE status != 'resolved'";
$params = [];

// Apply disaster type filter
if ($filter_type !== 'all' && $filter_type !== '') {
    $query .= " AND disaster_type = ?";
    $params[] = $filter_type;
}

// Apply severity filter
if ($filter_severity !== 'all' && $filter_severity !== '') {
    $query .= " AND severity = ?";
    $params[] = $filter_severity;
}

// Apply security level filter
if ($filter_security !== 'all' && $filter_security !== '') {
    switch($filter_security) {
        case 'critical':
            $query .= " AND severity = 'critical'";
            break;
        case 'high':
            $query .= " AND (severity = 'critical' OR severity = 'high')";
            break;
        case 'medium':
            $query .= " AND (severity = 'critical' OR severity = 'high' OR severity = 'medium')";
            break;
    }
}

$query .= " ORDER BY reported_at DESC";

$stmt = $conn->prepare($query);
if ($stmt) {
    // Build bind_param string and execute
    if (!empty($params)) {
        // Determine types for bind_param
        $types = '';
        foreach ($params as $param) {
            $types .= is_int($param) ? 'i' : 's';
        }
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $disasters = $result->fetch_all(MYSQLI_ASSOC);
} else {
    $disasters = [];
}

// Get total incidents
$totalQuery = "SELECT COUNT(*) as total FROM disasters WHERE status != 'resolved'";
$totalStmt = $conn->prepare($totalQuery);
if ($totalStmt) {
    $totalStmt->execute();
    $totalResult = $totalStmt->get_result();
    $totalRow = $totalResult->fetch_assoc();
    $totalIncidents = $totalRow['total'] ?? 0;
} else {
    $totalIncidents = 0;
}

// Get critical alerts count
$criticalQuery = "SELECT COUNT(*) as critical FROM disasters WHERE severity = 'critical' AND status != 'resolved'";
$criticalStmt = $conn->prepare($criticalQuery);
if ($criticalStmt) {
    $criticalStmt->execute();
    $criticalResult = $criticalStmt->get_result();
    $criticalRow = $criticalResult->fetch_assoc();
    $criticalAlerts = $criticalRow['critical'] ?? 0;
} else {
    $criticalAlerts = 0;
}

// Show success messages
$successMessage = '';
if (isset($_GET['message'])) {
    if ($_GET['message'] === 'deleted') {
        $successMessage = 'Disaster marked as resolved successfully!';
    } elseif ($_GET['message'] === 'added') {
        $successMessage = 'New disaster reported successfully!';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DisasterWatch - <?php echo $page_title; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #0f172a;
            --primary-blue: #3b82f6;
            --secondary-blue: #60a5fa;
            --critical-red: #ef4444;
            --high-orange: #f97316;
            --medium-yellow: #f59e0b;
            --low-green: #10b981;
            --card-bg: #ffffff;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --border-color: #e2e8f0;
            --sidebar-width: 300px;
            --header-height: 72px;
            --bg-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
            --radius-sm: 0.375rem;
            --radius-md: 0.5rem;
            --radius-lg: 0.75rem;
            --radius-xl: 1rem;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
        }

        .page-container {
            display: grid;
            grid-template-columns: 300px 1fr;
            grid-template-rows: 72px 1fr;
            min-height: 100vh;
            gap: 0;
        }

        /* Header */
        header {
            grid-column: 1 / -1;
            background: var(--primary-dark);
            color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 32px;
            box-shadow: var(--shadow-lg);
            z-index: 50;
            position: relative;
            backdrop-filter: blur(10px);
        }

        header::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--critical-red), var(--primary-blue), var(--low-green));
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 16px;
            position: relative;
        }

        .logo-icon {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .logo-icon::before {
            content: '';
            position: absolute;
            width: 36px;
            height: 36px;
            background: var(--critical-red);
            border-radius: 50%;
            opacity: 0.2;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 0.2; }
            50% { transform: scale(1.1); opacity: 0.3; }
        }

        .logo i {
            font-size: 28px;
            color: white;
            position: relative;
            z-index: 1;
        }

        .logo h1 {
            font-size: 24px;
            font-weight: 800;
            background: linear-gradient(135deg, #fff 0%, #cbd5e1 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            letter-spacing: -0.5px;
        }

        .header-nav {
            display: flex;
            align-items: center;
            gap: 24px;
            flex: 1;
            margin: 0 48px;
        }

        .nav-link {
            color: #cbd5e1;
            text-decoration: none;
            font-size: 15px;
            font-weight: 500;
            padding: 10px 18px;
            border-radius: var(--radius-md);
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 10px;
            position: relative;
        }

        .nav-link:hover {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            transform: translateY(-1px);
        }

        .nav-link.active {
            color: white;
            background: rgba(59, 130, 246, 0.2);
            font-weight: 600;
        }

        .nav-link.active::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 18px;
            right: 18px;
            height: 3px;
            background: var(--primary-blue);
            border-radius: 2px;
        }

        .header-info {
            display: flex;
            align-items: center;
            gap: 32px;
        }

        .timestamp, .real-time {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 14px;
            color: #94a3b8;
            padding: 8px 16px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: var(--radius-md);
            transition: var(--transition);
        }

        .timestamp:hover, .real-time:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateY(-1px);
        }

        .timestamp i {
            color: var(--medium-yellow);
        }

        .real-time i {
            color: var(--low-green);
            animation: spin 3s linear infinite;
        }

        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 16px;
            font-size: 15px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary-blue), var(--secondary-blue));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: white;
            box-shadow: var(--shadow-md);
        }

        .logout-btn {
            color: white;
            background: linear-gradient(135deg, var(--critical-red), #dc2626);
            padding: 10px 20px;
            border-radius: var(--radius-md);
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
            border: none;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.25);
        }

        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(239, 68, 68, 0.4);
            background: linear-gradient(135deg, #dc2626, #b91c1c);
        }

        /* Sidebar */
        .sidebar {
            background: white;
            border-right: 1px solid var(--border-color);
            padding: 32px 0;
            overflow-y: auto;
            box-shadow: var(--shadow-md);
            position: relative;
            z-index: 40;
        }

        .sidebar-section {
            padding: 0 24px;
            margin-bottom: 24px;
        }

        .stats-banner {
            background: linear-gradient(135deg, var(--primary-blue), #2563eb);
            border-radius: var(--radius-lg);
            padding: 24px;
            margin-bottom: 24px;
            color: white;
            box-shadow: var(--shadow-lg);
            position: relative;
            overflow: hidden;
        }

        .stats-banner::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200px;
            height: 200px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
        }

        .stats-banner h3 {
            font-size: 14px;
            font-weight: 600;
            opacity: 0.9;
            margin-bottom: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .stats-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .stats-value {
            font-size: 36px;
            font-weight: 800;
            line-height: 1;
        }

        .stats-icon {
            font-size: 32px;
            opacity: 0.8;
        }

        .filter-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-bottom: 24px;
        }

        .apply-filters-btn {
            background: linear-gradient(135deg, var(--low-green), #059669);
            color: white;
            border: none;
            padding: 14px;
            border-radius: var(--radius-md);
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.25);
        }

        .apply-filters-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(16, 185, 129, 0.4);
        }

        .reset-filters-btn {
            background: white;
            color: var(--text-secondary);
            border: 2px solid var(--border-color);
            padding: 14px;
            border-radius: var(--radius-md);
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .reset-filters-btn:hover {
            border-color: var(--primary-blue);
            color: var(--primary-blue);
            transform: translateY(-2px);
        }

        /* Accordion Styles */
        .accordion {
            width: 100%;
            margin-bottom: 12px;
            border-radius: var(--radius-lg);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--border-color);
            transition: var(--transition);
        }

        .accordion:hover {
            box-shadow: var(--shadow-md);
            border-color: var(--primary-blue);
        }

        .accordion-header {
            background: #f8fafc;
            padding: 18px 24px;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: var(--transition);
            border-bottom: 1px solid transparent;
        }

        .accordion-header:hover {
            background: #f1f5f9;
        }

        .accordion-header.active {
            background: #e0f2fe;
            border-bottom-color: var(--primary-blue);
        }

        .accordion-header h3 {
            margin: 0;
            font-size: 15px;
            font-weight: 600;
            color: var(--primary-dark);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .accordion-icon {
            font-size: 12px;
            color: var(--primary-blue);
            transition: var(--transition);
        }

        .accordion-header.active .accordion-icon {
            transform: rotate(180deg);
        }

        .accordion-content {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            background: white;
        }

        .accordion-content.active {
            max-height: 400px;
            overflow-y: auto;
        }

        .accordion-inner {
            padding: 24px;
            animation: fadeIn 0.3s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .filter-options {
            list-style: none;
        }

        .filter-options li {
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            padding: 4px 0;
        }

        .filter-options input[type="radio"] {
            margin-right: 12px;
            width: 18px;
            height: 18px;
            cursor: pointer;
            accent-color: var(--primary-blue);
        }

        .filter-options label {
            cursor: pointer;
            font-size: 15px;
            display: flex;
            align-items: center;
            width: 100%;
            padding: 8px 0;
            color: var(--text-secondary);
            transition: var(--transition);
            border-radius: var(--radius-sm);
            padding-left: 8px;
        }

        .filter-options label:hover {
            color: var(--primary-blue);
            background: #f8fafc;
            padding-left: 12px;
        }

        .filter-options input[type="radio"]:checked + label {
            color: var(--primary-blue);
            font-weight: 600;
            background: #e0f2fe;
        }

        .severity-levels {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .severity-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 16px;
            border-radius: var(--radius-md);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .severity-item::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 4px;
            background: currentColor;
            opacity: 0.3;
        }

        .severity-item:hover {
            transform: translateX(4px);
            box-shadow: var(--shadow-sm);
        }

        .severity-item.active {
            background: rgba(59, 130, 246, 0.1);
            border-left: 4px solid var(--primary-blue);
            box-shadow: var(--shadow-sm);
        }

        .severity-critical {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(239, 68, 68, 0.05));
            color: var(--critical-red);
        }

        .severity-high {
            background: linear-gradient(135deg, rgba(249, 115, 22, 0.1), rgba(249, 115, 22, 0.05));
            color: var(--high-orange);
        }

        .severity-medium {
            background: linear-gradient(135deg, rgba(245, 158, 11, 0.1), rgba(245, 158, 11, 0.05));
            color: var(--medium-yellow);
        }

        .severity-low {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(16, 185, 129, 0.05));
            color: var(--low-green);
        }

        .severity-indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            flex-shrink: 0;
        }

        .indicator-critical {
            background: var(--critical-red);
            box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.2);
        }

        .indicator-high {
            background: var(--high-orange);
            box-shadow: 0 0 0 3px rgba(249, 115, 22, 0.2);
        }

        .indicator-medium {
            background: var(--medium-yellow);
            box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.2);
        }

        .indicator-low {
            background: var(--low-green);
            box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.2);
        }

        /* Main Content */
        .main-content {
            padding: 32px;
            overflow-y: auto;
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            position: relative;
        }

        .main-content::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 240px;
            background: linear-gradient(135deg, var(--primary-dark), #1e293b);
            clip-path: polygon(0 0, 100% 0, 100% 80%, 0 100%);
            z-index: 0;
        }

        .dashboard-header {
            position: relative;
            z-index: 1;
            margin-bottom: 32px;
        }

        .dashboard-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .dashboard-title h2 {
            font-size: 32px;
            font-weight: 800;
            color: white;
            margin: 0;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .incident-count {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            color: white;
            padding: 12px 24px;
            border-radius: 50px;
            font-weight: 700;
            font-size: 16px;
            white-space: nowrap;
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 16px;
            margin-bottom: 32px;
            flex-wrap: wrap;
            position: relative;
            z-index: 1;
        }

        .action-btn {
            padding: 16px 28px;
            border-radius: var(--radius-lg);
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 12px;
            border: none;
            position: relative;
            overflow: hidden;
        }

        .action-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s ease;
        }

        .action-btn:hover::before {
            left: 100%;
        }

        .action-btn.primary {
            background: linear-gradient(135deg, var(--primary-blue), #2563eb);
            color: white;
            box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
        }

        .action-btn.primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(59, 130, 246, 0.4);
        }

        .action-btn.success {
            background: linear-gradient(135deg, var(--low-green), #059669);
            color: white;
            box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
        }

        .action-btn.success:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.4);
        }

        .action-btn.danger {
            background: linear-gradient(135deg, var(--critical-red), #dc2626);
            color: white;
            box-shadow: 0 4px 15px rgba(239, 68, 68, 0.3);
        }

        .action-btn.danger:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(239, 68, 68, 0.4);
        }

        /* Success Message */
        .success-message {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(16, 185, 129, 0.05));
            color: var(--low-green);
            padding: 20px 24px;
            border-radius: var(--radius-lg);
            margin-bottom: 32px;
            border-left: 4px solid var(--low-green);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: relative;
            z-index: 1;
            backdrop-filter: blur(10px);
            animation: slideIn 0.5s ease-out;
        }

        @keyframes slideIn {
            from { transform: translateY(-10px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        /* Filter Info */
        .filter-info {
            background: white;
            padding: 20px 24px;
            border-radius: var(--radius-lg);
            margin-bottom: 32px;
            border: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
            position: relative;
            z-index: 1;
            box-shadow: var(--shadow-md);
        }

        .filter-info span {
            font-size: 15px;
            color: var(--text-primary);
        }

        .filter-info strong {
            color: var(--primary-blue);
            font-weight: 700;
        }

        /* Disaster Cards */
        .disaster-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
            gap: 28px;
            margin-bottom: 48px;
            position: relative;
            z-index: 1;
        }

        .disaster-card {
            background: white;
            border-radius: var(--radius-xl);
            box-shadow: var(--shadow-md);
            overflow: hidden;
            transition: var(--transition);
            position: relative;
            border: 1px solid var(--border-color);
        }

        .disaster-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
        }

        .disaster-card[data-severity="critical"]::before { background: linear-gradient(90deg, var(--critical-red), #dc2626); }
        .disaster-card[data-severity="high"]::before { background: linear-gradient(90deg, var(--high-orange), #ea580c); }
        .disaster-card[data-severity="medium"]::before { background: linear-gradient(90deg, var(--medium-yellow), #d97706); }
        .disaster-card[data-severity="low"]::before { background: linear-gradient(90deg, var(--low-green), #059669); }

        .disaster-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-xl);
        }

        .disaster-header {
            padding: 24px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            position: relative;
        }

        .disaster-type {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--primary-dark);
        }

        .disaster-location {
            font-size: 14px;
            color: var(--text-secondary);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .disaster-location i {
            color: var(--primary-blue);
        }

        .disaster-severity {
            padding: 8px 16px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            box-shadow: var(--shadow-sm);
        }

        .severity-critical-bg {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(239, 68, 68, 0.05));
            color: var(--critical-red);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .severity-high-bg {
            background: linear-gradient(135deg, rgba(249, 115, 22, 0.1), rgba(249, 115, 22, 0.05));
            color: var(--high-orange);
            border: 1px solid rgba(249, 115, 22, 0.2);
        }

        .severity-medium-bg {
            background: linear-gradient(135deg, rgba(245, 158, 11, 0.1), rgba(245, 158, 11, 0.05));
            color: var(--medium-yellow);
            border: 1px solid rgba(245, 158, 11, 0.2);
        }

        .severity-low-bg {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(16, 185, 129, 0.05));
            color: var(--low-green);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .disaster-details {
            padding: 0 24px 24px;
        }

        .disaster-description {
            margin-bottom: 24px;
            font-size: 15px;
            color: var(--text-secondary);
            line-height: 1.7;
        }

        .disaster-stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 24px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
        }

        .stat-item {
            text-align: center;
            padding: 16px;
            background: #f8fafc;
            border-radius: var(--radius-lg);
            transition: var(--transition);
        }

        .stat-item:hover {
            background: #f1f5f9;
            transform: translateY(-2px);
        }

        .stat-value {
            font-size: 24px;
            font-weight: 800;
            color: var(--primary-dark);
            margin-bottom: 4px;
        }

        .stat-label {
            font-size: 12px;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 600;
        }

        .disaster-status {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .status-badge {
            padding: 8px 16px;
            border-radius: 50px;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: 0.3px;
        }

        .status-active {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(16, 185, 129, 0.05));
            color: var(--low-green);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .status-warning {
            background: linear-gradient(135deg, rgba(249, 115, 22, 0.1), rgba(249, 115, 22, 0.05));
            color: var(--high-orange);
            border: 1px solid rgba(249, 115, 22, 0.2);
        }

        .status-monitoring {
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(59, 130, 246, 0.05));
            color: var(--primary-blue);
            border: 1px solid rgba(59, 130, 246, 0.2);
        }

        .update-time {
            font-size: 12px;
            color: var(--text-secondary);
            font-weight: 500;
        }

        .card-actions {
            position: absolute;
            top: 20px;
            right: 20px;
            display: flex;
            gap: 8px;
            opacity: 0;
            transition: var(--transition);
        }

        .disaster-card:hover .card-actions {
            opacity: 1;
        }

        .card-action-btn {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: none;
            cursor: pointer;
            transition: var(--transition);
            background: white;
            box-shadow: var(--shadow-md);
            color: var(--text-secondary);
        }

        .card-action-btn:hover {
            transform: scale(1.1) translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .card-action-btn.delete {
            color: var(--critical-red);
        }

        .card-action-btn.delete:hover {
            background: var(--critical-red);
            color: white;
        }

        /* No Results */
        .no-results {
            text-align: center;
            padding: 80px 40px;
            background: white;
            border-radius: var(--radius-xl);
            box-shadow: var(--shadow-lg);
            position: relative;
            z-index: 1;
            margin-top: 32px;
            border: 2px dashed var(--border-color);
        }

        .no-results i {
            font-size: 64px;
            color: #cbd5e1;
            margin-bottom: 24px;
            opacity: 0.5;
        }

        .no-results h3 {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary-dark);
            margin-bottom: 12px;
        }

        .no-results p {
            font-size: 16px;
            color: var(--text-secondary);
            margin-bottom: 32px;
            max-width: 400px;
            margin-left: auto;
            margin-right: auto;
        }

        /* SMALLER MODAL STYLES */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(15, 23, 42, 0.8);
            backdrop-filter: blur(8px);
            z-index: 1000;
            justify-content: center;
            align-items: center;
            padding: 20px;
            animation: fadeIn 0.3s ease-out;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: white;
            border-radius: var(--radius-xl);
            width: 100%;
            max-width: 500px; /* Reduced from 600px */
            max-height: 85vh; /* Reduced from 90vh */
            overflow-y: auto;
            box-shadow: var(--shadow-2xl);
            animation: modalSlideIn 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        @keyframes modalSlideIn {
            from {
                opacity: 0;
                transform: translateY(-30px) scale(0.95);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        .modal-header {
            padding: 20px 24px; /* Reduced padding */
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: linear-gradient(135deg, var(--primary-dark), #1e293b);
            color: white;
            border-radius: var(--radius-xl) var(--radius-xl) 0 0;
        }

        .modal-header h3 {
            font-size: 20px; /* Reduced font size */
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px; /* Reduced gap */
        }

        .close-modal {
            background: rgba(255, 255, 255, 0.1);
            border: none;
            width: 32px; /* Reduced size */
            height: 32px; /* Reduced size */
            border-radius: 50%;
            font-size: 18px; /* Reduced font size */
            color: white;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .close-modal:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: rotate(90deg);
        }

        .modal-body {
            padding: 24px; /* Reduced padding */
        }

        .form-group {
            margin-bottom: 18px; /* Reduced margin */
        }

        .form-group label {
            display: block;
            margin-bottom: 8px; /* Reduced margin */
            font-weight: 600;
            color: var(--primary-dark);
            font-size: 14px; /* Reduced font size */
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 16px; /* Reduced padding */
            border: 2px solid var(--border-color);
            border-radius: var(--radius-md);
            font-size: 14px; /* Reduced font size */
            transition: var(--transition);
            background: white;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            border-color: var(--primary-blue);
            outline: none;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        .form-group textarea {
            min-height: 100px; /* Reduced height */
            resize: vertical;
            line-height: 1.5;
        }

        .form-row {
            display: flex;
            gap: 16px; /* Reduced gap */
            margin-bottom: 18px; /* Added margin */
        }

        .form-row .form-group {
            flex: 1;
            margin-bottom: 0;
        }

        .modal-footer {
            padding: 20px 24px; /* Reduced padding */
            border-top: 1px solid var(--border-color);
            display: flex;
            justify-content: flex-end;
            gap: 12px; /* Reduced gap */
            background: #f8fafc;
            border-radius: 0 0 var(--radius-xl) var(--radius-xl);
        }

        .modal-footer .action-btn {
            padding: 12px 20px; /* Reduced padding */
            font-size: 14px; /* Reduced font size */
        }

        .delete-modal .modal-body {
            text-align: center;
            padding: 32px 24px; /* Reduced padding */
        }

        .delete-modal .modal-body i {
            font-size: 48px; /* Reduced size */
            color: var(--critical-red);
            margin-bottom: 16px; /* Reduced margin */
            opacity: 0.8;
        }

        .delete-modal .modal-body h4 {
            font-size: 18px; /* Reduced size */
            margin-bottom: 12px;
        }

        .delete-modal .modal-body p {
            font-size: 14px;
            color: var(--text-secondary);
            margin-bottom: 24px;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .disaster-grid {
                grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
            }
        }

        @media (max-width: 992px) {
            .page-container {
                grid-template-columns: 1fr;
                grid-template-rows: auto 1fr;
            }
            
            .sidebar {
                display: none;
            }
            
            .header-nav {
                display: none;
            }
            
            .header-info {
                flex-direction: column;
                gap: 16px;
                align-items: flex-end;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                padding: 24px;
            }
            
            .disaster-grid {
                grid-template-columns: 1fr;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .action-btn {
                width: 100%;
                justify-content: center;
            }
            
            .dashboard-title {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .form-row {
                flex-direction: column;
                gap: 12px; /* Reduced gap for mobile */
            }
            
            header {
                padding: 0 20px;
            }
            
            .modal-content {
                max-width: 95%; /* Make modal wider on mobile */
            }
        }

        @media (max-width: 480px) {
            .main-content {
                padding: 16px;
            }
            
            .modal-body {
                padding: 20px;
            }
            
            .modal-footer {
                flex-direction: column;
            }
            
            .modal-footer .action-btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="page-container">
        <!-- Header -->
        <header>
            <div class="logo">
                <div class="logo-icon">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <h1>DisasterWatch</h1>
            </div>
            
            <nav class="header-nav">
                <a href="dashboard.php" class="nav-link active">
                    <i class="fas fa-home"></i> Dashboard
                </a>
                <a href="resources.php" class="nav-link">
                    <i class="fas fa-hands-helping"></i> Resources
                </a>
            </nav>
            
            <div class="header-info">
                <div class="timestamp">
                    <i class="fas fa-clock"></i>
                    <span>Last updated: <?php echo date('n/j/Y, g:i:s A'); ?></span>
                </div>
                <div class="real-time">
                    <i class="fas fa-satellite-dish"></i>
                    <span>Live Tracking</span>
                </div>
                <div class="user-info">
                    <div class="user-avatar">
                        <?php echo strtoupper(substr($first_name, 0, 1)); ?>
                    </div>
                    <span>Welcome, <?php echo htmlspecialchars($first_name); ?></span>
                    <a href="logout.php" class="logout-btn">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </header>

        <!-- Sidebar -->
        <aside class="sidebar">
            <form id="filter-form" method="GET" action="">
                <div class="sidebar-section">
                    <div class="stats-banner">
                        <h3>Critical Alerts</h3>
                        <div class="stats-content">
                            <div class="stats-value"><?php echo $criticalAlerts; ?></div>
                            <i class="fas fa-bell stats-icon"></i>
                        </div>
                    </div>
                </div>

                <div class="sidebar-section">
                    <div class="filter-buttons">
                        <button type="submit" class="apply-filters-btn">
                            <i class="fas fa-filter"></i> Apply Filters
                        </button>
                        <button type="button" class="reset-filters-btn" id="reset-filters">
                            <i class="fas fa-redo"></i> Reset
                        </button>
                    </div>
                </div>

                <!-- Disaster Type Accordion -->
                <div class="accordion">
                    <div class="accordion-header" data-target="type-accordion">
                        <h3><i class="fas fa-bolt"></i> Disaster Type</h3>
                        <span class="accordion-icon"><i class="fas fa-chevron-down"></i></span>
                    </div>
                    <div class="accordion-content" id="type-accordion">
                        <div class="accordion-inner">
                            <ul class="filter-options">
                                <li>
                                    <input type="radio" id="type-all" name="type" value="all" 
                                           <?php echo $filter_type === 'all' ? 'checked' : ''; ?>>
                                    <label for="type-all">All Types</label>
                                </li>
                                <li>
                                    <input type="radio" id="type-earthquake" name="type" value="earthquake"
                                           <?php echo $filter_type === 'earthquake' ? 'checked' : ''; ?>>
                                    <label for="type-earthquake">Earthquake</label>
                                </li>
                                <li>
                                    <input type="radio" id="type-hurricane" name="type" value="hurricane"
                                           <?php echo $filter_type === 'hurricane' ? 'checked' : ''; ?>>
                                    <label for="type-hurricane">Hurricane</label>
                                </li>
                                <li>
                                    <input type="radio" id="type-flood" name="type" value="flood"
                                           <?php echo $filter_type === 'flood' ? 'checked' : ''; ?>>
                                    <label for="type-flood">Flood</label>
                                </li>
                                <li>
                                    <input type="radio" id="type-wildfire" name="type" value="wildfire"
                                           <?php echo $filter_type === 'wildfire' ? 'checked' : ''; ?>>
                                    <label for="type-wildfire">Wildfire</label>
                                </li>
                                <li>
                                    <input type="radio" id="type-tsunami" name="type" value="tsunami"
                                           <?php echo $filter_type === 'tsunami' ? 'checked' : ''; ?>>
                                    <label for="type-tsunami">Tsunami</label>
                                </li>
                                <li>
                                    <input type="radio" id="type-tornado" name="type" value="tornado"
                                           <?php echo $filter_type === 'tornado' ? 'checked' : ''; ?>>
                                    <label for="type-tornado">Tornado</label>
                                </li>
                                <li>
                                    <input type="radio" id="type-volcano" name="type" value="volcano"
                                           <?php echo $filter_type === 'volcano' ? 'checked' : ''; ?>>
                                    <label for="type-volcano">Volcano</label>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Severity Levels Accordion -->
                <div class="accordion">
                    <div class="accordion-header" data-target="severity-accordion">
                        <h3><i class="fas fa-exclamation-triangle"></i> Severity Levels</h3>
                        <span class="accordion-icon"><i class="fas fa-chevron-down"></i></span>
                    </div>
                    <div class="accordion-content" id="severity-accordion">
                        <div class="accordion-inner">
                            <div class="severity-levels">
                                <div class="severity-item severity-critical <?php echo $filter_severity === 'critical' ? 'active' : ''; ?>" 
                                     data-severity="critical">
                                    <span class="severity-indicator indicator-critical"></span>
                                    <span>Critical</span>
                                    <input type="radio" id="severity-critical" name="severity" value="critical" 
                                           <?php echo $filter_severity === 'critical' ? 'checked' : ''; ?> style="display: none;">
                                </div>
                                <div class="severity-item severity-high <?php echo $filter_severity === 'high' ? 'active' : ''; ?>" 
                                     data-severity="high">
                                    <span class="severity-indicator indicator-high"></span>
                                    <span>High</span>
                                    <input type="radio" id="severity-high" name="severity" value="high" 
                                           <?php echo $filter_severity === 'high' ? 'checked' : ''; ?> style="display: none;">
                                </div>
                                <div class="severity-item severity-medium <?php echo $filter_severity === 'medium' ? 'active' : ''; ?>" 
                                     data-severity="medium">
                                    <span class="severity-indicator indicator-medium"></span>
                                    <span>Medium</span>
                                    <input type="radio" id="severity-medium" name="severity" value="medium" 
                                           <?php echo $filter_severity === 'medium' ? 'checked' : ''; ?> style="display: none;">
                                </div>
                                <div class="severity-item severity-low <?php echo $filter_severity === 'low' ? 'active' : ''; ?>" 
                                     data-severity="low">
                                    <span class="severity-indicator indicator-low"></span>
                                    <span>Low</span>
                                    <input type="radio" id="severity-low" name="severity" value="low" 
                                           <?php echo $filter_severity === 'low' ? 'checked' : ''; ?> style="display: none;">
                                </div>
                                <div class="severity-item <?php echo $filter_severity === 'all' ? 'active' : ''; ?>" 
                                     style="background-color: #f8fafc;" data-severity="all">
                                    <span class="severity-indicator" style="background-color: #94a3b8; box-shadow: 0 0 0 3px rgba(148, 163, 184, 0.2);"></span>
                                    <span>All Severities</span>
                                    <input type="radio" id="severity-all" name="severity" value="all" 
                                           <?php echo $filter_severity === 'all' ? 'checked' : ''; ?> style="display: none;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Security Level Accordion -->
                <div class="accordion">
                    <div class="accordion-header" data-target="security-accordion">
                        <h3><i class="fas fa-shield-alt"></i> Security Level</h3>
                        <span class="accordion-icon"><i class="fas fa-chevron-down"></i></span>
                    </div>
                    <div class="accordion-content" id="security-accordion">
                        <div class="accordion-inner">
                            <ul class="filter-options">
                                <li>
                                    <input type="radio" id="security-all" name="security" value="all"
                                           <?php echo $filter_security === 'all' ? 'checked' : ''; ?>>
                                    <label for="security-all">All Levels</label>
                                </li>
                                <li>
                                    <input type="radio" id="security-critical" name="security" value="critical"
                                           <?php echo $filter_security === 'critical' ? 'checked' : ''; ?>>
                                    <label for="security-critical">Critical Only</label>
                                </li>
                                <li>
                                    <input type="radio" id="security-high" name="security" value="high"
                                           <?php echo $filter_security === 'high' ? 'checked' : ''; ?>>
                                    <label for="security-high">High & Above</label>
                                </li>
                                <li>
                                    <input type="radio" id="security-medium" name="security" value="medium"
                                           <?php echo $filter_security === 'medium' ? 'checked' : ''; ?>>
                                    <label for="security-medium">Medium & Above</label>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="sidebar-section" style="margin-top: 24px;">
                    <div class="stats-banner" style="background: linear-gradient(135deg, #8b5cf6, #7c3aed);">
                        <h3>Total Incidents</h3>
                        <div class="stats-content">
                            <div class="stats-value"><?php echo $totalIncidents; ?></div>
                            <i class="fas fa-chart-line stats-icon"></i>
                        </div>
                    </div>
                </div>
            </form>
        </aside>

        <main class="main-content">
            <div class="dashboard-header">
                <div class="dashboard-title">
                    <h2>Active Disasters</h2>
                    <div class="incident-count"><?php echo count($disasters); ?> Active Incidents</div>
                </div>

                <?php if ($successMessage): ?>
                    <div class="success-message" id="success-message">
                        <span><?php echo htmlspecialchars($successMessage); ?></span>
                        <button class="close-message" onclick="document.getElementById('success-message').style.display='none'" style="background: none; border: none; color: var(--low-green); cursor: pointer; font-size: 18px;">&times;</button>
                    </div>
                <?php endif; ?>

                <div class="action-buttons">
                    <button class="action-btn primary" onclick="openAddDisasterModal()">
                        <i class="fas fa-plus-circle"></i> Report New Disaster
                    </button>
                    <button class="action-btn success" onclick="window.open('real_time_map.php', '_blank')" title="Open real-time map in new tab">
                        <i class="fas fa-map-marked-alt"></i> View on Map
                    </button>
                    <button class="action-btn danger" onclick="window.location.href='dashboard.php?severity=critical'">
                        <i class="fas fa-exclamation-triangle"></i> View Critical Only
                    </button>
                </div>

                <?php 
                $has_filters = ($filter_type !== 'all' || $filter_severity !== 'all' || $filter_security !== 'all');
                if ($has_filters): 
                ?>
                <div class="filter-info">
                    <span>
                        Showing 
                        <strong><?php echo count($disasters); ?> disasters</strong>
                        <?php if ($filter_type !== 'all'): ?>
                            | Type: <strong><?php echo ucfirst($filter_type); ?></strong>
                        <?php endif; ?>
                        <?php if ($filter_severity !== 'all'): ?>
                            | Severity: <strong><?php echo ucfirst($filter_severity); ?></strong>
                        <?php endif; ?>
                        <?php if ($filter_security !== 'all'): ?>
                            | Security: <strong><?php echo ucfirst($filter_security); ?></strong>
                        <?php endif; ?>
                    </span>
                    <a href="dashboard.php" style="color: var(--primary-blue); text-decoration: none; font-size: 14px; font-weight: 600;">
                        <i class="fas fa-times"></i> Clear all filters
                    </a>
                </div>
                <?php endif; ?>
            </div>

            <?php if (empty($disasters)): ?>
                <div class="no-results">
                    <i class="fas fa-search"></i>
                    <h3>No active disasters found</h3>
                    <p>All disasters have been resolved or try adjusting your filters.</p>
                    <button class="action-btn primary" onclick="openAddDisasterModal()" style="margin-top: 24px;">
                        <i class="fas fa-plus-circle"></i> Report First Disaster
                    </button>
                </div>
            <?php else: ?>
                <div class="disaster-grid">
                    <?php foreach ($disasters as $disaster): ?>
                        <?php
                        $severityClass = 'severity-' . strtolower($disaster['severity']) . '-bg';
                        $statusClass = 'status-' . strtolower($disaster['status']);
                        $reportedDate = date('n/j/Y, g:i A', strtotime($disaster['reported_at']));
                        ?>
                        
                        <div class="disaster-card" data-id="<?php echo $disaster['id']; ?>" 
                             data-severity="<?php echo strtolower($disaster['severity']); ?>">
                            
                            <div class="card-actions">
                                <button class="card-action-btn delete" title="Mark as Resolved" 
                                        onclick="confirmDelete(<?php echo $disaster['id']; ?>, '<?php echo htmlspecialchars($disaster['title']); ?>')">
                                    <i class="fas fa-check-circle"></i>
                                </button>
                            </div>
                            
                            <div class="disaster-header">
                                <div>
                                    <div class="disaster-type"><?php echo htmlspecialchars($disaster['title']); ?></div>
                                    <div class="disaster-location">
                                        <i class="fas fa-map-marker-alt"></i>
                                        <span><?php echo htmlspecialchars($disaster['location']); ?></span>
                                    </div>
                                </div>
                                <div class="disaster-severity <?php echo $severityClass; ?>">
                                    <?php echo ucfirst($disaster['severity']); ?>
                                </div>
                            </div>
                            
                            <div class="disaster-details">
                                <p class="disaster-description"><?php echo htmlspecialchars($disaster['description']); ?></p>
                                
                                <div class="disaster-stats">
                                    <div class="stat-item">
                                        <div class="stat-value"><?php echo $disaster['radius_km']; ?> km</div>
                                        <div class="stat-label">Affected Radius</div>
                                    </div>
                                    <div class="stat-item">
                                        <div class="stat-value"><?php echo $disaster['casualties'] ?: '-'; ?></div>
                                        <div class="stat-label">Casualties</div>
                                    </div>
                                </div>
                                
                                <div class="disaster-status">
                                    <div class="status-badge <?php echo $statusClass; ?>"><?php echo ucfirst($disaster['status']); ?></div>
                                    <div class="update-time">Reported <?php echo $reportedDate; ?></div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>

    <!-- Add Disaster Modal (Smaller) -->
    <div class="modal" id="addDisasterModal">
        <div class="modal-content">
            <form method="POST" action="">
                <div class="modal-header">
                    <h3><i class="fas fa-plus-circle"></i> Report New Disaster</h3>
                    <button type="button" class="close-modal" onclick="closeAddDisasterModal()">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="disaster_type">Disaster Type *</label>
                            <select id="disaster_type" name="disaster_type" required>
                                <option value="">Select type</option>
                                <option value="earthquake">Earthquake</option>
                                <option value="hurricane">Hurricane</option>
                                <option value="flood">Flood</option>
                                <option value="wildfire">Wildfire</option>
                                <option value="tsunami">Tsunami</option>
                                <option value="tornado">Tornado</option>
                                <option value="volcano">Volcano</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="severity">Severity Level *</label>
                            <select id="severity" name="severity" required>
                                <option value="">Select severity</option>
                                <option value="critical">Critical</option>
                                <option value="high">High</option>
                                <option value="medium">Medium</option>
                                <option value="low">Low</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="title">Disaster Title *</label>
                        <input type="text" id="title" name="title" placeholder="e.g., Magnitude 6.8 Earthquake" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="location">Location *</label>
                        <input type="text" id="location" name="location" placeholder="e.g., Tokyo, Japan" required>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="radius_km">Affected Radius (km) *</label>
                            <input type="number" id="radius_km" name="radius_km" min="1" max="1000" required>
                        </div>
                        <div class="form-group">
                            <label for="casualties">Casualties (if any)</label>
                            <input type="number" id="casualties" name="casualties" min="0">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Description *</label>
                        <textarea id="description" name="description" placeholder="Describe the disaster including impact, affected areas, and current situation..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="action-btn" style="background-color: white; color: var(--text-secondary); border: 2px solid var(--border-color);" onclick="closeAddDisasterModal()">
                        Cancel
                    </button>
                    <button type="submit" class="action-btn primary" name="add_disaster">
                        <i class="fas fa-paper-plane"></i> Submit Report
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Confirmation Modal (Smaller) -->
    <div class="modal delete-modal" id="deleteModal">
        <div class="modal-content">
            <div class="modal-body">
                <i class="fas fa-check-circle"></i>
                <h4>Mark as Resolved</h4>
                <p>Are you sure you want to mark <strong id="disaster-name"></strong> as resolved?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="action-btn" style="background-color: white; color: var(--text-secondary); border: 2px solid var(--border-color);" onclick="closeDeleteModal()">
                    Cancel
                </button>
                <button type="button" class="action-btn danger" id="confirm-delete-btn">
                    <i class="fas fa-check"></i> Yes, Mark as Resolved
                </button>
            </div>
        </div>
    </div>

    <?php include('includes/footer.php'); ?>

    <script>
        // Accordion functionality
        document.addEventListener('DOMContentLoaded', function() {
            const accordionHeaders = document.querySelectorAll('.accordion-header');
            
            accordionHeaders.forEach(header => {
                header.addEventListener('click', function() {
                    const targetId = this.getAttribute('data-target');
                    const content = document.getElementById(targetId);
                    
                    // Toggle active class on header
                    this.classList.toggle('active');
                    
                    // Toggle active class on content
                    content.classList.toggle('active');
                    
                    // Close other accordions (optional - remove if you want multiple open)
                    accordionHeaders.forEach(otherHeader => {
                        if (otherHeader !== this) {
                            const otherTargetId = otherHeader.getAttribute('data-target');
                            const otherContent = document.getElementById(otherTargetId);
                            otherHeader.classList.remove('active');
                            otherContent.classList.remove('active');
                        }
                    });
                });
            });
            
            // Open accordions based on active filters
            if ('<?php echo $filter_type; ?>' !== 'all') {
                const typeAccordion = document.querySelector('[data-target="type-accordion"]');
                if (typeAccordion) {
                    typeAccordion.click();
                }
            } else if ('<?php echo $filter_severity; ?>' !== 'all') {
                const severityAccordion = document.querySelector('[data-target="severity-accordion"]');
                if (severityAccordion) {
                    severityAccordion.click();
                }
            } else if ('<?php echo $filter_security; ?>' !== 'all') {
                const securityAccordion = document.querySelector('[data-target="security-accordion"]');
                if (securityAccordion) {
                    securityAccordion.click();
                }
            }
        });

        function openAddDisasterModal() {
            document.getElementById('addDisasterModal').classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeAddDisasterModal() {
            document.getElementById('addDisasterModal').classList.remove('active');
            document.body.style.overflow = 'auto';
        }

        let disasterToDelete = null;

        function confirmDelete(disasterId, disasterName) {
            disasterToDelete = disasterId;
            document.getElementById('disaster-name').textContent = disasterName;
            document.getElementById('deleteModal').classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeDeleteModal() {
            document.getElementById('deleteModal').classList.remove('active');
            disasterToDelete = null;
            document.body.style.overflow = 'auto';
        }

        document.getElementById('confirm-delete-btn').addEventListener('click', function() {
            if (disasterToDelete) {
                window.location.href = 'dashboard.php?delete=' + disasterToDelete;
            }
        });

        window.addEventListener('click', function(event) {
            const addModal = document.getElementById('addDisasterModal');
            const deleteModal = document.getElementById('deleteModal');
            
            if (event.target === addModal) {
                closeAddDisasterModal();
            }
            if (event.target === deleteModal) {
                closeDeleteModal();
            }
        });

        const successMessage = document.getElementById('success-message');
        if (successMessage) {
            setTimeout(() => {
                successMessage.style.opacity = '0';
                setTimeout(() => {
                    successMessage.style.display = 'none';
                }, 300);
            }, 5000);
        }

        // Severity level selection
        const severityItems = document.querySelectorAll('.severity-item[data-severity]');
        severityItems.forEach(item => {
            item.addEventListener('click', function() {
                const severity = this.getAttribute('data-severity');
                const radioInput = this.querySelector('input[type="radio"]');
                if (radioInput) {
                    radioInput.checked = true;
                    
                    // Remove active class from all items
                    severityItems.forEach(i => i.classList.remove('active'));
                    // Add active class to clicked item
                    this.classList.add('active');
                }
            });
        });

        // Reset filters button
        const resetBtn = document.getElementById('reset-filters');
        if (resetBtn) {
            resetBtn.addEventListener('click', function() {
                window.location.href = 'dashboard.php';
            });
        }

        // Update time every second
        function updateTime() {
            const now = new Date();
            const timeString = now.toLocaleDateString('en-US', {
                month: 'numeric',
                day: 'numeric',
                year: 'numeric',
                hour: 'numeric',
                minute: '2-digit',
                second: '2-digit',
                hour12: true
            });
            
            const timeElement = document.querySelector('.timestamp span');
            if (timeElement) {
                timeElement.textContent = 'Last updated: ' + timeString;
            }
        }
        
        // Update time initially and every second
        updateTime();
        setInterval(updateTime, 1000);
    </script>
</body>
</html>