<?php
include('includes/config.php');

// Redirect if already logged in
if(isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

// Process sign up
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = $conn->real_escape_string($_POST['first_name']);
    $last_name = $conn->real_escape_string($_POST['last_name']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validate passwords match
    if($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        // Check if email already exists
        $check_sql = "SELECT id FROM users WHERE email = '$email'";
        $check_result = $conn->query($check_sql);
        
        if($check_result->num_rows > 0) {
            $error = "Email already registered.";
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert user
            $sql = "INSERT INTO users (first_name, last_name, email, password) 
                    VALUES ('$first_name', '$last_name', '$email', '$hashed_password')";
            
            if($conn->query($sql) === TRUE) {
                // Auto sign in
                $user_id = $conn->insert_id;
                $_SESSION['user_id'] = $user_id;
                $_SESSION['first_name'] = $first_name;
                $_SESSION['email'] = $email;
                
                header("Location: dashboard.php");
                exit();
            } else {
                $error = "Registration failed. Please try again.";
            }
        }
    }
}

$page_title = "Sign Up";
include('includes/header.php');
?>

<div class="auth-container">
    <div class="auth-card">
        <div class="auth-header">
            <h1>DisasterWatch</h1>
            <p>Create Your Account<br>Sign up to get started with disaster alerts</p>
        </div>
        
        <?php if(isset($error)): ?>
            <div style="background: #ffebee; color: #c62828; padding: 1rem; border-radius: 6px; margin-bottom: 1.5rem;">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group" style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div>
                    <label for="first_name" class="form-label">First Name *</label>
                    <input type="text" id="first_name" name="first_name" class="form-control" placeholder="First Name" required>
                </div>
                <div>
                    <label for="last_name" class="form-label">Last Name *</label>
                    <input type="text" id="last_name" name="last_name" class="form-control" placeholder="Last Name" required>
                </div>
            </div>
            
            <div class="form-group">
                <label for="email" class="form-label">Email Address *</label>
                <input type="email" id="email" name="email" class="form-control" placeholder="your.email@example.com" required>
            </div>
            
            <div class="form-group">
                <label for="password" class="form-label">Password *</label>
                <input type="password" id="password" name="password" class="form-control" placeholder="Create a password" required>
            </div>
            
            <div class="form-group">
                <label for="confirm_password" class="form-label">Confirm Password *</label>
                <input type="password" id="confirm_password" name="confirm_password" class="form-control" placeholder="Confirm your password" required>
            </div>
            
            <button type="submit" class="btn btn-block">Sign Up</button>
        </form>
        
        <div class="auth-footer">
            <p>Already have an account? <a href="signin.php">Sign in</a></p>
        </div>
        
        <div style="text-align: center; margin: 2rem 0; color: #666; font-size: 0.9rem;">
            Or continue with
        </div>
        
        <button class="btn btn-block btn-google">
            <i class="fab fa-google"></i> Continue with Google
        </button>
    </div>
</div>

<?php include('includes/footer.php'); ?>