<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DisasterWatch - <?php echo $page_title ?? 'Real-time Emergency Monitoring'; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
</head>
<body>
    <header class="header">
        <nav class="navbar">
            <div class="nav-container">
                <div class="logo">
                    <a href="index.php">
                        <i class="fas fa-exclamation-triangle"></i>
                        <span>DisasterWatch</span>
                    </a>
                </div>
                
                <div class="nav-menu">
                    <a href="index.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
                        <i class="fas fa-home"></i> Home
                    </a>
                    
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <a href="dashboard.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                        <a href="logout.php" class="nav-link">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                        <span class="user-welcome">
                            <i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['first_name']); ?>
                        </span>
                    <?php else: ?>
                        <a href="signin.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'signin.php' ? 'active' : ''; ?>" onclick="if(document.getElementById('dw-signin-overlay')){ event.preventDefault(); openModal('dw-signin-overlay'); }">
                            <i class="fas fa-sign-in-alt"></i> Sign In
                        </a>
                        <a href="signup.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'signup.php' ? 'active' : ''; ?>" onclick="if(document.getElementById('dw-signup-overlay')){ event.preventDefault(); openModal('dw-signup-overlay'); }">
                            <i class="fas fa-user-plus"></i> Sign Up
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>
    
    <main class="main-content">