    </main>
    
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-section">
                <h3><i class="fas fa-exclamation-triangle"></i> DisasterWatch</h3>
                <p>Real-time disaster monitoring, instant emergency alerts, and comprehensive preparedness resources to keep your community safe.</p>
            </div>
            
            <div class="footer-section">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="signin.php">Sign In</a></li>
                    <li><a href="signup.php">Sign Up</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h4>Emergency Resources</h4>
                <ul>
                    <li><a href="#">Preparedness Guides</a></li>
                    <li><a href="#">Emergency Contacts</a></li>
                    <li><a href="#">Evacuation Routes</a></li>
                    <li><a href="#">Shelter Locations</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h4>Contact</h4>
                <p><i class="fas fa-phone"></i> Emergency Hotline: 1-800-123-4567</p>
                <p><i class="fas fa-envelope"></i> support@disasterwatch.org</p>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> DisasterWatch. All rights reserved. | System Active – Monitoring 24/7</p>
        </div>
    </footer>
    
    <script src="assets/js/script.js"></script>
</body>
</html>