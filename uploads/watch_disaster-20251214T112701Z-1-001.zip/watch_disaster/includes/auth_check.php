<?php
// Check if user is logged in, redirect to signin if not
if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit();
}

// Get user info from session
$user_id = $_SESSION['user_id'];
$first_name = $_SESSION['first_name'];
$email = $_SESSION['email'];
?>