<?php
include('includes/config.php');
$page_title = "Real-time Emergency Monitoring";
include('includes/header.php');
?>

<div class="hero">
    <div class="hero-content">
        <h1>Protecting Communities Through Early Warning & Disaster Resilience</h1>
        <p class="hero-subtitle">Real-time disaster monitoring, instant emergency alerts, and comprehensive preparedness resources to keep your community safe. Our advanced early warning system provides critical information when every second counts during natural disasters and emergency situations.</p>
        
        <div class="hero-buttons">
            <?php if(isset($_SESSION['user_id'])): ?>
                <a href="dashboard.php" class="btn">View Dashboard</a>
            <?php else: ?>
                <button type="button" class="btn" id="open-signup">Get Emergency Alerts</button>
                <button type="button" class="btn" id="open-signin" style="background: transparent; border: 2px solid white;">Sign In</button>
            <?php endif; ?>
        </div>
        
        <div class="hero-stats">
            <div class="stat-item">
                <span class="stat-number">1,247</span>
                <span class="stat-label">Active Monitoring Locations</span>
            </div>
            <div class="stat-item">
                <span class="stat-number">24/7</span>
                <span class="stat-label">System Monitoring</span>
            </div>
            <div class="stat-item">
                <span class="stat-number"><?php 
                    $result = $conn->query("SELECT COUNT(*) as count FROM alerts WHERE is_active = TRUE");
                    $row = $result->fetch_assoc();
                    echo $row['count'];
                ?></span>
                <span class="stat-label">Active Alerts</span>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="card">
        <h2 class="section-title">How DisasterWatch Works</h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 2rem; margin-top: 2rem;">
            <div class="feature">
                <i class="fas fa-satellite-dish" style="font-size: 3rem; color: #1a237e; margin-bottom: 1rem;"></i>
                <h3>Real-time Monitoring</h3>
                <p>Our system continuously monitors seismic activity, weather patterns, and emergency reports from official sources.</p>
            </div>
            <div class="feature">
                <i class="fas fa-bell" style="font-size: 3rem; color: #ff5252; margin-bottom: 1rem;"></i>
                <h3>Instant Alerts</h3>
                <p>Receive immediate notifications about emergencies in your area through multiple channels.</p>
            </div>
            <div class="feature">
                <i class="fas fa-map-marked-alt" style="font-size: 3rem; color: #4caf50; margin-bottom: 1rem;"></i>
                <h3>Live Emergency Map</h3>
                <p>Visualize active emergencies and their impact zones on our interactive map.</p>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>

<!-- Signin / Signup Modals -->
<style>
/* Modal overlay */
.dw-modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.06); display: none; align-items: center; justify-content: center; z-index: 1050; backdrop-filter: blur(6px) brightness(0.92); }
.dw-modal { background: rgba(255,255,255,0.56); border-radius: 12px; width: 480px; max-width: calc(100% - 32px); box-shadow: 0 6px 20px rgba(10,10,10,0.08); padding: 26px 28px; position: relative; border: 1px solid rgba(255,255,255,0.35); backdrop-filter: blur(4px) saturate(120%); }
.dw-modal .modal-brand { text-align: center; margin-bottom: 8px; }
.dw-modal .modal-brand h1 { margin: 0; font-size: 28px; color: #1a237e; }
.dw-modal .modal-sub { text-align: center; color: #666; font-size: 14px; margin-bottom: 18px; }
.dw-modal h3 { margin:0 0 10px 0; font-size: 18px; }
.dw-modal .form-group { margin-bottom: 12px; }
.dw-modal label { display:block; font-weight:600; margin-bottom:6px; }
.dw-modal input[type="text"], .dw-modal input[type="email"], .dw-modal input[type="password"] { width:100%; padding:14px 12px; border-radius:8px; border:1px solid #eee; font-size:14px; }
.dw-modal .actions { display:flex; gap:8px; justify-content:flex-end; margin-top:12px; }
.dw-btn { background: linear-gradient(180deg,#24358f,#1a237e); color:#fff; padding:12px 14px; border-radius:8px; border:none; cursor:pointer; font-weight:600; width:100%; }
.dw-btn.ghost { background: transparent; border:1px solid #ddd; color:#333; width:auto; padding:10px 12px; }
.dw-modal .close-x { position:absolute; right:12px; top:12px; cursor:pointer; color:#888; font-size:20px; }
.dw-error { color:#c4171f; margin-top:6px; font-size:13px; }
.dw-small-link { display:block; text-align:center; margin-top:10px; color:#1a237e; text-decoration:none; font-weight:600; }
.dw-or { text-align:center; color:#999; margin:14px 0; }
.dw-google { display:flex; align-items:center; gap:10px; border:1px solid #e6e6e6; padding:10px; border-radius:8px; justify-content:center; cursor:pointer; background:#fff; }
.dw-grid-2 { display:flex; gap:10px; }
.dw-grid-2 .form-group { flex:1; }
/* prevent body scroll when modal open */
body.dw-modal-open { overflow: hidden; }
</style>

<div id="dw-signin-overlay" class="dw-modal-overlay" aria-hidden="true">
    <div class="dw-modal" role="dialog" aria-modal="true" aria-labelledby="dw-signin-title">
        <div style="position:relative;">
            <span class="close-x" onclick="closeModal('dw-signin-overlay')">&times;</span>
            <div class="modal-brand"><h1>DisasterWatch</h1></div>
            <div class="modal-sub">Sign in to access your alert preferences</div>
            <div id="dw-signin-error" class="dw-error" style="display:none;"></div>
            <form id="dw-signin-form" onsubmit="return false;">
                <div class="form-group">
                    <label for="signin-email">Email Address *</label>
                    <input id="signin-email" name="email" type="email" placeholder="your.email@example.com" required />
                </div>
                <div class="form-group">
                    <label for="signin-password">Password *</label>
                    <input id="signin-password" name="password" type="password" placeholder="Enter your password" required />
                </div>
                <div style="margin-top:6px; text-align:right;">
                    <a href="#" class="dw-small-link" onclick="closeModal('dw-signin-overlay'); openModal('dw-signup-overlay'); return false;">Don't have an account? Sign up</a>
                </div>
                <div class="actions">
                    <button type="button" class="dw-btn ghost" onclick="closeModal('dw-signin-overlay')">Cancel</button>
                </div>
                <div style="margin-top:8px;">
                    <button type="button" id="dw-signin-submit" class="dw-btn">Sign In</button>
                </div>
                <div class="dw-or">Or continue with</div>
                <div class="dw-google" onclick="alert('Google login not configured')">
                    <img src="https://www.gstatic.com/devrel-devsite/prod/vd0c2f4fb9d7a0c6f2e6b2e6b3e8f0c1d1/google.svg" alt="G" style="height:18px;"/>
                    <div>Continue with Google</div>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="dw-signup-overlay" class="dw-modal-overlay" aria-hidden="true">
    <div class="dw-modal" role="dialog" aria-modal="true" aria-labelledby="dw-signup-title">
        <div style="position:relative;">
            <span class="close-x" onclick="closeModal('dw-signup-overlay')">&times;</span>
            <div class="modal-brand"><h1>DisasterWatch</h1></div>
            <div class="modal-sub">Create Your Account — Sign up to get started with disaster alerts</div>
            <div id="dw-signup-error" class="dw-error" style="display:none;"></div>
            <form id="dw-signup-form" onsubmit="return false;">
                <div class="dw-grid-2">
                    <div class="form-group">
                        <label for="signup-first">First Name *</label>
                        <input id="signup-first" name="first_name" type="text" placeholder="First Name" required />
                    </div>
                    <div class="form-group">
                        <label for="signup-last">Last Name *</label>
                        <input id="signup-last" name="last_name" type="text" placeholder="Last Name" required />
                    </div>
                </div>
                <div class="form-group">
                    <label for="signup-email">Email Address *</label>
                    <input id="signup-email" name="email" type="email" placeholder="your.email@example.com" required />
                </div>
                <div class="form-group">
                    <label for="signup-password">Password *</label>
                    <input id="signup-password" name="password" type="password" placeholder="Create a password" required />
                </div>
                <div class="form-group">
                    <label for="signup-confirm">Confirm Password *</label>
                    <input id="signup-confirm" name="confirm_password" type="password" placeholder="Confirm your password" required />
                </div>
                <div class="actions">
                    <button type="button" class="dw-btn ghost" onclick="closeModal('dw-signup-overlay')">Cancel</button>
                </div>
                <div style="margin-top:8px;">
                    <button type="button" id="dw-signup-submit" class="dw-btn">Sign Up</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// modal helpers
function openModal(id){
    const el = document.getElementById(id);
    if(!el) return;
    // close any other open overlays to avoid duplicates
    document.querySelectorAll('.dw-modal-overlay').forEach(o=>{
        if(o.id !== id){
            o.style.display = 'none';
            o.setAttribute('aria-hidden', 'true');
        }
    });

    el.style.display = 'flex';
    el.setAttribute('aria-hidden', 'false');
    // prevent body scroll
    document.body.classList.add('dw-modal-open');
}
function closeModal(id){
    const el = document.getElementById(id);
    if(!el) return;
    el.style.display = 'none';
    el.setAttribute('aria-hidden', 'true');
    // restore body scroll only if no other overlay is visible
    const anyOpen = Array.from(document.querySelectorAll('.dw-modal-overlay')).some(o => o.style.display === 'flex');
    if(!anyOpen) document.body.classList.remove('dw-modal-open');
}

// wire buttons
document.addEventListener('DOMContentLoaded', function(){
    const openSignin = document.getElementById('open-signin');
    const openSignup = document.getElementById('open-signup');
    if(openSignin) openSignin.addEventListener('click', ()=> openModal('dw-signin-overlay'));
    if(openSignup) openSignup.addEventListener('click', ()=> openModal('dw-signup-overlay'));

    // Signin AJAX
    const signinForm = document.getElementById('dw-signin-form');
    if(signinForm){
        // keep submit handler as fallback, but use button click
        signinForm.addEventListener('submit', function(e){ e.preventDefault(); });
        const signinBtn = document.getElementById('dw-signin-submit');
        if(signinBtn) signinBtn.addEventListener('click', function(){
            const fd = new FormData(signinForm);
            fetch('includes/signin_process.php', { method: 'POST', body: fd })
                .then(r=>r.json())
                .then(data=>{
                    if(data.success){
                        window.location.href = data.redirect || 'dashboard.php';
                    } else {
                        const err = document.getElementById('dw-signin-error');
                        err.textContent = data.message || 'Sign in failed'; err.style.display = 'block';
                    }
                }).catch(err=>{
                    const eDiv = document.getElementById('dw-signin-error'); eDiv.textContent = 'Network error'; eDiv.style.display = 'block';
                });
        });
    }

    // Signup AJAX
    const signupForm = document.getElementById('dw-signup-form');
    if(signupForm){
        // keep submit handler as fallback, but use button click
        signupForm.addEventListener('submit', function(e){ e.preventDefault(); });
        const signupBtn = document.getElementById('dw-signup-submit');
        if(signupBtn) signupBtn.addEventListener('click', function(){
            const fd = new FormData(signupForm);
            fetch('includes/signup_process.php', { method: 'POST', body: fd })
                .then(r=>r.json())
                .then(data=>{
                    if(data.success){
                        window.location.href = data.redirect || 'dashboard.php';
                    } else {
                        const err = document.getElementById('dw-signup-error');
                        err.textContent = data.message || 'Sign up failed'; err.style.display = 'block';
                    }
                }).catch(err=>{
                    const eDiv = document.getElementById('dw-signup-error'); eDiv.textContent = 'Network error'; eDiv.style.display = 'block';
                });
        });
    }
});
// close on ESC
document.addEventListener('keydown', function(e){
    if(e.key === 'Escape'){
        const overlays = document.querySelectorAll('.dw-modal-overlay');
        overlays.forEach(o=>{ if(o.style.display === 'flex') closeModal(o.id); });
    }
});
// click outside modal to close
document.querySelectorAll('.dw-modal-overlay').forEach(overlay=>{
    overlay.addEventListener('click', function(e){
        if(e.target === overlay) closeModal(overlay.id);
    });
});
</script>