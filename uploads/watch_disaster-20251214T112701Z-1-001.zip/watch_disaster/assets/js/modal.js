// Modal functionality
document.addEventListener('DOMContentLoaded', function() {
    // Initialize modals
    const signinModal = document.getElementById('signinModal');
    const signupModal = document.getElementById('signupModal');
    const forgotPasswordModal = document.getElementById('forgotPasswordModal');
    const successModal = document.getElementById('successModal');
    const errorModal = document.getElementById('errorModal');
    
    // Check URL parameters for modal opening
    const urlParams = new URLSearchParams(window.location.search);
    const modalParam = urlParams.get('modal');
    
    if (modalParam === 'signin') {
        openSignInModal();
    } else if (modalParam === 'signup') {
        openSignUpModal();
    }
    
    // Close modal when clicking outside
    window.onclick = function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
            document.body.classList.remove('modal-open');
        }
    }
    
    // Handle sign in form submission
    const signinForm = document.getElementById('signinForm');
    if (signinForm) {
        signinForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('includes/signin_process.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showSuccessMessage(data.message);
                    setTimeout(() => {
                        window.location.href = data.redirect;
                    }, 1500);
                } else {
                    showErrorMessage(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showErrorMessage('An error occurred. Please try again.');
            });
        });
    }
    
    // Handle sign up form submission
    const signupForm = document.getElementById('signupForm');
    if (signupForm) {
        signupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const password = document.getElementById('modal_signup_password').value;
            const confirmPassword = document.getElementById('modal_confirm_password').value;
            
            if (password !== confirmPassword) {
                showErrorMessage('Passwords do not match!');
                return;
            }
            
            const formData = new FormData(this);
            
            fetch('includes/signup_process.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showSuccessMessage(data.message);
                    setTimeout(() => {
                        window.location.href = data.redirect;
                    }, 1500);
                } else {
                    showErrorMessage(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showErrorMessage('An error occurred. Please try again.');
            });
        });
    }
    
    // Handle forgot password form
    const forgotPasswordForm = document.getElementById('forgotPasswordForm');
    if (forgotPasswordForm) {
        forgotPasswordForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('reset_email').value;
            
            // In a real application, this would make an API call
            setTimeout(() => {
                closeForgotPasswordModal();
                showSuccessMessage('Password reset instructions have been sent to your email.');
            }, 1000);
        });
    }
});

// Modal control functions
function openSignInModal() {
    const modal = document.getElementById('signinModal');
    modal.style.display = 'block';
    document.body.classList.add('modal-open');
    
    // Close other modals
    closeSignUpModal();
    closeForgotPasswordModal();
}

function closeSignInModal() {
    const modal = document.getElementById('signinModal');
    modal.style.display = 'none';
    document.body.classList.remove('modal-open');
}

function openSignUpModal() {
    const modal = document.getElementById('signupModal');
    modal.style.display = 'block';
    document.body.classList.add('modal-open');
    
    // Close other modals
    closeSignInModal();
    closeForgotPasswordModal();
}

function closeSignUpModal() {
    const modal = document.getElementById('signupModal');
    modal.style.display = 'none';
    document.body.classList.remove('modal-open');
}

function showForgotPassword() {
    const modal = document.getElementById('forgotPasswordModal');
    modal.style.display = 'block';
    document.body.classList.add('modal-open');
    
    // Close other modals
    closeSignInModal();
    closeSignUpModal();
}

function closeForgotPasswordModal() {
    const modal = document.getElementById('forgotPasswordModal');
    modal.style.display = 'none';
    document.body.classList.remove('modal-open');
}

function switchToSignUp() {
    closeSignInModal();
    closeForgotPasswordModal();
    openSignUpModal();
}

function switchToSignIn() {
    closeSignUpModal();
    closeForgotPasswordModal();
    openSignInModal();
}

function showSuccessMessage(message) {
    const modal = document.getElementById('successModal');
    const messageElement = document.getElementById('successMessage');
    
    messageElement.textContent = message;
    modal.style.display = 'block';
    document.body.classList.add('modal-open');
    
    // Close other modals
    closeSignInModal();
    closeSignUpModal();
    closeForgotPasswordModal();
}

function closeSuccessModal() {
    const modal = document.getElementById('successModal');
    modal.style.display = 'none';
    document.body.classList.remove('modal-open');
}

function showErrorMessage(message) {
    const modal = document.getElementById('errorModal');
    const messageElement = document.getElementById('errorMessage');
    
    messageElement.textContent = message;
    modal.style.display = 'block';
    document.body.classList.add('modal-open');
}

function closeErrorModal() {
    const modal = document.getElementById('errorModal');
    modal.style.display = 'none';
    document.body.classList.remove('modal-open');
}

// Keyboard shortcuts for modals
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeSignInModal();
        closeSignUpModal();
        closeForgotPasswordModal();
        closeSuccessModal();
        closeErrorModal();
    }
});