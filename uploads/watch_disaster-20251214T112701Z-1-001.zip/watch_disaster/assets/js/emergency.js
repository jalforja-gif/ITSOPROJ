import express from 'express';
import { pool } from './db.js';
const router = express.Router();

// GET all
router.get('/emergency-contacts', async (req, res) => {
  const result = await pool.query("SELECT * FROM emergency_contacts ORDER BY id");
  res.json(result.rows);
});

// CREATE
router.post('/emergency-contacts', async (req, res) => {
  const { name, phone, availability } = req.body;
  const result = await pool.query(
    "INSERT INTO emergency_contacts (name, phone, availability) VALUES ($1, $2, $3) RETURNING *",
    [name, phone, availability]
  );
  res.json(result.rows[0]);
});

// UPDATE
router.put('/emergency-contacts/:id', async (req, res) => {
  const { name, phone, availability } = req.body;
  const result = await pool.query(
    "UPDATE emergency_contacts SET name=$1, phone=$2, availability=$3, updated_at=NOW() WHERE id=$4 RETURNING *",
    [name, phone, availability, req.params.id]
  );
  res.json(result.rows[0]);
});

// DELETE
router.delete('/emergency-contacts/:id', async (req, res) => {
  await pool.query("DELETE FROM emergency_contacts WHERE id=$1", [req.params.id]);
  res.json({ message: "Deleted" });
});

export default router;
