// Alert filtering functionality
document.addEventListener('DOMContentLoaded', function() {
    // Severity filter buttons
    const filterButtons = document.querySelectorAll('.filter-btn');
    const alertItems = document.querySelectorAll('.alert-item');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
            
            const severity = this.getAttribute('data-severity');
            
            // Show/hide alert items based on severity
            alertItems.forEach(item => {
                if (severity === 'all' || item.classList.contains(severity.toLowerCase())) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });
    
    // Simulate real-time alert updates
    if (window.location.pathname.includes('dashboard.php')) {
        updateAlertCounts();
        setInterval(updateAlertCounts, 30000); // Update every 30 seconds
    }
    
    // Form validation
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const password = this.querySelector('input[type="password"]');
            const confirmPassword = this.querySelector('input[name="confirm_password"]');
            
            if (confirmPassword && password.value !== confirmPassword.value) {
                e.preventDefault();
                alert('Passwords do not match!');
                confirmPassword.focus();
            }
        });
    });
});

function updateAlertCounts() {
    // In a real application, this would fetch from an API
    console.log('Updating alert counts...');
    
    // Simulate new alert
    const criticalBadge = document.querySelector('.badge-critical');
    if (criticalBadge && Math.random() > 0.7) {
        const count = parseInt(criticalBadge.textContent) + 1;
        criticalBadge.textContent = count;
        
        // Show notification
        showNotification('New critical alert received!');
    }
}

function showNotification(message) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.innerHTML = `
        <i class="fas fa-exclamation-circle"></i>
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">&times;</button>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #ff5252;
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        display: flex;
        align-items: center;
        gap: 10px;
        z-index: 9999;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

// Add notification styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    .notification button {
        background: none;
        border: none;
        color: white;
        font-size: 1.5rem;
        cursor: pointer;
        padding: 0;
        margin-left: 10px;
        
    }
`;
// Disaster type filter buttons
const filterButtons = document.querySelectorAll('.filter-btn[data-type]');
const disasterTypeInput = document.getElementById('disaster-type-input');

filterButtons.forEach(button => {
    button.addEventListener('click', function() {
        const selectedType = this.getAttribute('data-type');
        
        // Update input value
        disasterTypeInput.value = selectedType;
        
        // Update active state
        filterButtons.forEach(btn => btn.classList.remove('active'));
        this.classList.add('active');
        
        // Optional: Auto-submit the form
        // document.getElementById('filter-form').submit();
    });
});

// Security level filter buttons
const securityButtons = document.querySelectorAll('.security-btn');
const securityLevelInput = document.getElementById('security-level-input');

securityButtons.forEach(button => {
    button.addEventListener('click', function() {
        const selectedSecurity = this.getAttribute('data-security');
        
        // Update input value
        securityLevelInput.value = selectedSecurity;
        
        // Update active state
        securityButtons.forEach(btn => btn.classList.remove('active'));
        this.classList.add('active');
        
        // Optional: Auto-submit the form
        // document.getElementById('filter-form').submit();
    });
});

// Auto-submit when clicking filter buttons (optional - uncomment if desired)
/*
filterButtons.forEach(button => {
    button.addEventListener('click', function() {
        const selectedType = this.getAttribute('data-type');
        disasterTypeInput.value = selectedType;
        document.getElementById('filter-form').submit();
    });
});

securityButtons.forEach(button => {
    button.addEventListener('click', function() {
        const selectedSecurity = this.getAttribute('data-security');
        securityLevelInput.value = selectedSecurity;
        document.getElementById('filter-form').submit();
    });
});
*/
document.head.appendChild(style);

