<?php
include('includes/config.php');
include('includes/auth_check.php');

$page_title = "Real-time Map - Disaster Watch";

function isInsidePhilippines($lat, $lng) {
    $minLat = 4.586567;
    $maxLat = 21.321780;
    $minLng = 116.954926;
    $maxLng = 126.604385;
    return ($lat >= $minLat && $lat <= $maxLat && $lng >= $minLng && $lng <= $maxLng);
}

// Handle new disaster submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_disaster'])) {
    $disaster_type = $_POST['disaster_type'] ?? '';
    $title = $_POST['title'] ?? '';
    $location = $_POST['location'] ?? '';
    $severity = $_POST['severity'] ?? '';
    $description = $_POST['description'] ?? '';
    $radius_km = (int)($_POST['radius_km'] ?? 0);
    $casualties = (int)($_POST['casualties'] ?? 0);
    $status = $_POST['status'] ?? 'active';
    $latitude = isset($_POST['latitude']) && $_POST['latitude'] !== '' ? (float)$_POST['latitude'] : null;
    $longitude = isset($_POST['longitude']) && $_POST['longitude'] !== '' ? (float)$_POST['longitude'] : null;

    if (empty($title) || empty($location) || empty($disaster_type) || empty($severity)) {
        $error = 'Please fill required fields: title, location, type, severity.';
    } else {
        // Geocode if no coordinates
        if (empty($latitude) || empty($longitude)) {
            function geocodeLocation($q) {
                $q = trim($q);
                if ($q === '') return null;
                $url = 'https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=ph&q=' . urlencode($q);
                $opts = ['http' => ['header' => "User-Agent: DisasterWatch/1.0\r\nAccept-Language: en\r\n"]];
                $context = stream_context_create($opts);
                $resp = @file_get_contents($url, false, $context);
                if ($resp !== false) {
                    $data = json_decode($resp, true);
                    if (!empty($data[0]) && isset($data[0]['lat']) && isset($data[0]['lon'])) {
                        return ['lat' => (float)$data[0]['lat'], 'lon' => (float)$data[0]['lon']];
                    }
                }
                return null;
            }
            $geo = geocodeLocation($location);
            if ($geo) {
                $latitude = $geo['lat'];
                $longitude = $geo['lon'];
            }
        }

        // Insert disaster
        $insertQuery = "INSERT INTO disasters (disaster_type, title, location, severity, description, radius_km, casualties, status, latitude, longitude, reported_at, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)";
        $stmt = $conn->prepare($insertQuery);
        if ($stmt) {
            $latVar = $latitude !== null ? $latitude : null;
            $lngVar = $longitude !== null ? $longitude : null;
            $createdBy = $_SESSION['user_id'];

            $types = 'sssssii';
            $params = [$disaster_type, $title, $location, $severity, $description, $radius_km, $casualties];
            $types .= 's'; $params[] = $status;
            $types .= 'ss'; $params[] = $latVar !== null ? (string)$latVar : null;
            $params[] = $lngVar !== null ? (string)$lngVar : null;
            $types .= 'i'; $params[] = $createdBy;

            $bind_names[] = $types;
            for ($i=0; $i<count($params); $i++) {
                $bind_name = 'bind' . $i;
                $$bind_name = $params[$i];
                $bind_names[] = &$$bind_name;
            }
            call_user_func_array([$stmt, 'bind_param'], $bind_names);

            if ($stmt->execute()) {
                if ($latitude !== null && $longitude !== null && !isInsidePhilippines($latitude, $longitude)) {
                    $error = "Error: Coordinates must be inside the Philippines only.";
                } else {
                    header('Location: real_time_map.php?message=added');
                    exit();
                }
            } else {
                $error = 'DB insert failed: ' . $stmt->error;
            }
        }
    }
}

// Fetch active disasters
$query = "SELECT id, disaster_type, title, location, severity, description, radius_km, casualties, status, reported_at, latitude, longitude FROM disasters WHERE status != 'resolved' AND LOWER(location) LIKE '%philippines%' ORDER BY reported_at DESC";
$res = $conn->query($query);
$disasters = [];
if ($res) while ($row = $res->fetch_assoc()) $disasters[] = $row;

// Prepare markers JSON
$mapMarkers = [];
foreach ($disasters as $d) {
    if (!empty($d['latitude']) && !empty($d['longitude'])) {
        $mapMarkers[] = [
            'id' => $d['id'],
            'title' => $d['title'],
            'type' => $d['disaster_type'],
            'severity' => $d['severity'],
            'lat' => (float)$d['latitude'],
            'lng' => (float)$d['longitude'],
            'desc' => $d['description']
        ];
    }
}
$mapMarkersJson = json_encode($mapMarkers);
$googleApiKey = getenv('GOOGLE_MAPS_API_KEY') ?: '';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo $page_title; ?></title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css"/>
<link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css"/>
<style>
body { font-family: Arial, sans-serif; margin:0; padding:0; }
header { background:#0a1931; color:#fff; padding:12px 18px; display:flex; justify-content:space-between; align-items:center; }
#map { height: calc(100vh - 140px); width: 100%; }
.container { display:flex; gap:20px; padding:18px; }
.panel { width:360px; background:#fff; border-radius:8px; padding:16px; box-shadow:0 4px 12px rgba(0,0,0,0.08); height: calc(100vh - 140px); overflow:auto; }
.panel h2 { margin:0 0 12px 0; }
.form-group { margin-bottom:12px; }
label { display:block; font-weight:600; margin-bottom:6px; }
input[type=text], textarea, select, input[type=number] { width:100%; padding:8px 10px; border:1px solid #ddd; border-radius:6px; }
.btn { background:#1a5fb4; color:#fff; padding:10px 12px; border:none; border-radius:6px; cursor:pointer; }
.btn.secondary { background:#f5f7fa; color:#333; border:1px solid #ddd; }
.list-item { padding:8px; border-bottom:1px solid #f0f0f0; }
.coords-note { font-size:13px; color:#666; }
</style>
</head>
<body>
<header>
<div>DisasterWatch — Real-time Map (Philippines)</div>
<div>Welcome, <?php echo htmlspecialchars($_SESSION['first_name'] ?? 'User'); ?></div>
</header>
<div class="container">
<div id="map"></div>
<aside class="panel">
<h2>Report / Add Disaster</h2>
<?php if (!empty($error)): ?>
<div style="color:#c4171f;margin-bottom:12px;"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>
<form method="POST" action="">
<div class="form-group">
<label for="disaster_type">Disaster Type</label>
<select id="disaster_type" name="disaster_type" required>
<option value="earthquake">Earthquake</option>
<option value="hurricane">Hurricane</option>
<option value="flood">Flood</option>
<option value="wildfire">Wildfire</option>
<option value="tsunami">Tsunami</option>
<option value="tornado">Tornado</option>
<option value="volcano">Volcano</option>
</select>
</div>
<div class="form-group">
<label for="title">Title</label>
<input type="text" id="title" name="title" required />
</div>
<div class="form-group">
<label for="location">Location (text)</label>
<input type="text" id="location" name="location" value="Philippines" required />
</div>
<div class="form-group">
<label for="severity">Severity</label>
<select id="severity" name="severity" required>
<option value="critical">Critical</option>
<option value="high">High</option>
<option value="medium">Medium</option>
<option value="low">Low</option>
</select>
</div>
<div class="form-group">
<label for="radius_km">Radius (km)</label>
<input type="number" id="radius_km" name="radius_km" min="0" />
</div>
<div class="form-group">
<label for="casualties">Casualties</label>
<input type="number" id="casualties" name="casualties" min="0" />
</div>
<div class="form-group">
<label for="latitude">Latitude</label>
<input type="text" id="latitude" name="latitude" placeholder="Click map to fill" />
</div>
<div class="form-group">
<label for="longitude">Longitude</label>
<input type="text" id="longitude" name="longitude" placeholder="Click map to fill" />
</div>
<div class="form-group">
<label for="description">Description</label>
<textarea id="description" name="description" rows="4"></textarea>
</div>
<div style="display:flex;gap:8px;">
<button type="submit" name="add_disaster" class="btn">Submit</button>
<button type="button" id="clear-coords" class="btn secondary">Clear Coords</button>
</div>
<p class="coords-note">Tip: click on the map to set Latitude/Longitude for the report.</p>
</form>

<h2 style="margin-top:16px;">Active Disasters (Philippines)</h2>
<?php if (empty($disasters)): ?>
<div>No active disasters recorded in the Philippines.</div>
<?php else: ?>
<?php foreach ($disasters as $d): ?>
<div class="list-item">
<strong><?php echo htmlspecialchars($d['title']); ?></strong><br>
<small><?php echo htmlspecialchars($d['location']); ?> — <?php echo htmlspecialchars(ucfirst($d['severity'])); ?></small>
<?php if ($d['latitude'] && $d['longitude']): ?>
<div style="font-size:12px;color:#666;">Coords: <?php echo $d['latitude']; ?>, <?php echo $d['longitude']; ?></div>
<?php endif; ?>
</div>
<?php endforeach; ?>
<?php endif; ?>
</aside>
</div>

<?php if ($googleApiKey): ?>
<!-- Google Maps version -->
<script src="https://unpkg.com/@googlemaps/markerclusterer/dist/index.min.js"></script>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=<?php echo $googleApiKey; ?>&callback=initMap"></script>
<script>
let map; let tempMarker=null; 
const markersFromPHP = <?php echo $mapMarkersJson; ?>;

function escapeHtml(str){return String(str).replace(/[&<>"'`]/g,function(s){return({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;', '`':'&#96;'})[s];});}

function initMap(){
map = new google.maps.Map(document.getElementById('map'), {center:{lat:12.8797,lng:121.7740},zoom:6});
const gmarkers = markersFromPHP.map(d=>{
const marker = new google.maps.Marker({position:{lat:d.lat,lng:d.lng},title:d.title});
const info = new google.maps.InfoWindow({content:`<strong>${escapeHtml(d.title)}</strong><br>${escapeHtml(d.type)} — ${escapeHtml(d.severity)}<br>${escapeHtml(d.desc)}`});
marker.addListener('click',()=>info.open(map,marker));
return marker;
});
new markerClusterer.MarkerClusterer({map:map,markers:gmarkers});
map.addListener('click',(e)=>{
const lat=e.latLng.lat().toFixed(6); const lng=e.latLng.lng().toFixed(6);
document.getElementById('latitude').value=lat;
document.getElementById('longitude').value=lng;
if(tempMarker) tempMarker.setMap(null);
tempMarker=new google.maps.Marker({position:{lat:parseFloat(lat),lng:parseFloat(lng)},map:map});
});
document.getElementById('clear-coords').addEventListener('click',function(){
document.getElementById('latitude').value='';
document.getElementById('longitude').value='';
if(tempMarker){tempMarker.setMap(null); tempMarker=null;}
});
}
</script>
<?php else: ?>
<!-- Leaflet fallback -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js"></script>
<script>
const map=L.map('map').setView([12.8797,121.7740],6);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'}).addTo(map);
const disasters=<?php echo $mapMarkersJson; ?>;
const clusterGroup=L.markerClusterGroup();
disasters.forEach(d=>{
const color=d.severity==='critical'?'#e01b24':(d.severity==='high'?'#ff7800':(d.severity==='medium'?'#f6d32d':'#26a269'));
const marker=L.circleMarker([d.lat,d.lng],{radius:8,color:color,fillColor:color,fillOpacity:0.9});
marker.bindPopup(`<strong>${d.title}</strong><br>${d.type} — ${d.severity}<br>${d.desc}`);
clusterGroup.addLayer(marker);
});
map.addLayer(clusterGroup);
map.on('click',function(e){
const lat=e.latlng.lat.toFixed(6); const lng=e.latlng.lng.toFixed(6);
document.getElementById('latitude').value=lat;
document.getElementById('longitude').value=lng;
if(window.tempMarker) map.removeLayer(window.tempMarker);
window.tempMarker=L.marker([lat,lng]).addTo(map);
});
document.getElementById('clear-coords').addEventListener('click',function(){
document.getElementById('latitude').value='';
document.getElementById('longitude').value='';
if(window.tempMarker){map.removeLayer(window.tempMarker); window.tempMarker=null;}
});
</script>
<?php endif; ?>
</body>
</html>
