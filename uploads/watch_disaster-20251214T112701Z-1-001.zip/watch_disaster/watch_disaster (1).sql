-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2025 at 02:12 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `watch_disaster`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `alerts`
--

CREATE TABLE `alerts` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `severity` enum('CRITICAL','HIGH','MODERATE','LOW') NOT NULL,
  `region` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `alerts`
--

INSERT INTO `alerts` (`id`, `title`, `description`, `severity`, `region`, `created_at`, `updated_at`, `is_active`) VALUES
(1, 'Magnitude 6.8 Earthquake Detected', 'Strong seismic activity detected. Tsunami warning issued for coastal areas. Evacuate to higher ground immediately.', 'CRITICAL', 'Pacific Coast Region', '2025-12-01 21:39:41', '2025-12-01 21:51:41', 1),
(2, 'Flash Flood Warning', 'Heavy rainfall causing rapid water rise. Avoid low-lying areas and do not attempt to cross flooded roads.', 'CRITICAL', 'Central Valley Area', '2025-12-01 21:21:41', '2025-12-01 21:51:41', 1),
(3, 'Rapidly Spreading Wildfire', 'Fire spreading at 15 mph due to high winds. Mandatory evacuation orders for zones A, B, and C.', 'HIGH', 'Northern Forest District', '2025-12-01 21:06:41', '2025-12-01 21:51:41', 1),
(4, 'Industrial Hazardous Material Leak', 'Chemical leak detected at industrial plant. Shelter in place order for surrounding 5-mile radius.', 'HIGH', 'Industrial Zone 7', '2025-12-01 20:51:41', '2025-12-01 21:51:41', 1),
(5, 'Hurricane Watch - Category 3', 'Hurricane approaching with sustained winds of 120 mph. Expected landfall in 36-48 hours. Prepare emergency supplies.', 'MODERATE', 'Eastern Coastal Region', '2025-12-01 19:51:41', '2025-12-01 21:51:41', 1),
(6, 'Severe Thunderstorm Warning', 'Large hail and damaging winds expected. Seek shelter indoors immediately.', 'MODERATE', 'Midwest Region', '2025-12-01 18:51:41', '2025-12-01 21:51:41', 1);

-- --------------------------------------------------------

--
-- Table structure for table `disasters`
--

CREATE TABLE `disasters` (
  `id` int(11) NOT NULL,
  `disaster_type` varchar(50) NOT NULL,
  `title` varchar(200) NOT NULL,
  `location` varchar(150) NOT NULL,
  `severity` enum('critical','high','medium','low') NOT NULL DEFAULT 'medium',
  `description` text NOT NULL,
  `radius_km` int(11) DEFAULT 0,
  `casualties` int(11) DEFAULT 0,
  `status` enum('active','monitoring','resolved') NOT NULL DEFAULT 'active',
  `reported_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `disasters`
--

INSERT INTO `disasters` (`id`, `disaster_type`, `title`, `location`, `severity`, `description`, `radius_km`, `casualties`, `status`, `reported_at`, `created_by`, `created_at`, `updated_at`, `latitude`, `longitude`) VALUES
(1, 'earthquake', '8.1 earthquake', 'manila, philippines', 'critical', 'gana na boss', 1, 0, 'active', '2025-12-05 17:28:09', 1, '2025-12-05 17:28:09', '2025-12-05 17:32:28', 14.5995000, 120.9842000),
(2, 'flood', 'flood', 'manila, philippines', 'critical', 'patulong ya', 250, 0, 'active', '2025-12-05 17:28:09', 1, '2025-12-05 17:28:09', '2025-12-05 17:32:28', 14.5995000, 120.9842000),
(3, 'earthquake', 'earthquake ', 'manila, philippines', 'high', 'a', 2, 1, '', '2025-12-05 17:31:17', 2, '2025-12-05 17:31:17', '2025-12-05 17:32:28', 14.5995000, 120.9842000),
(4, 'earthquake', 'Earthqueke', 'Philippines', 'critical', '', 0, 0, 'active', '2025-12-09 11:50:45', 3, '2025-12-09 11:50:45', '2025-12-09 11:50:45', 12.7503486, 122.7312101),
(5, 'earthquake', 'Earthqueke', 'Philippines', 'critical', '', 0, 0, 'resolved', '2025-12-09 11:50:48', 3, '2025-12-09 11:50:48', '2025-12-10 02:05:44', 12.7503486, 122.7312101),
(6, 'earthquake', 'asd', 'Philippines', 'low', '123', 12, 213, 'active', '2025-12-10 02:06:44', 3, '2025-12-10 02:06:44', '2025-12-10 02:06:44', 999.9999999, 123.0000000),
(7, 'earthquake', '123', 'Philippines', 'critical', '', 123, 21123, 'active', '2025-12-10 02:07:19', 3, '2025-12-10 02:07:19', '2025-12-10 02:07:19', 14.1953630, 121.2386780),
(8, 'hurricane', '2.0', 'los banos', 'medium', 'medium lang ngani', 1, 1, '', '2025-12-10 09:16:42', 3, '2025-12-10 09:16:42', '2025-12-10 09:16:42', NULL, NULL),
(9, 'flood', 'level 1', 'los banos', 'high', 'high flood level', 1, 1, 'resolved', '2025-12-10 09:29:33', 3, '2025-12-10 09:29:33', '2025-12-10 09:29:43', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `emergency_contacts`
--

CREATE TABLE `emergency_contacts` (
  `id` int(11) NOT NULL,
  `contact_type` enum('SERVICES','HOTLINE','ORGANIZATION','GOVERNMENT') NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `availability` varchar(50) DEFAULT '24/7',
  `description` text DEFAULT NULL,
  `priority` int(11) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `emergency_contacts`
--

INSERT INTO `emergency_contacts` (`id`, `contact_type`, `name`, `phone`, `availability`, `description`, `priority`, `created_at`) VALUES
(1, 'SERVICES', 'Emergency Services', '911', '24/7', 'General emergency number for police, fire, and medical', 1, '2025-12-10 10:44:29'),
(2, 'HOTLINE', 'Disaster Hotline', '1-800-DISASTER', '24/7', 'National disaster response hotline', 2, '2025-12-10 10:44:29'),
(3, 'ORGANIZATION', 'Red Cross', '1-800-RED-CROSS', '24/7', 'Humanitarian organization for disaster relief', 3, '2025-12-10 10:44:29'),
(4, 'GOVERNMENT', 'FEMA Helpline', '1-800-621-3382', '24/7', 'Federal Emergency Management Agency', 4, '2025-12-10 10:44:29');

-- --------------------------------------------------------

--
-- Table structure for table `evacuation_centers`
--

CREATE TABLE `evacuation_centers` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(100) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `capacity` int(11) NOT NULL,
  `current_occupancy` int(11) DEFAULT 0,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `contact_phone` varchar(50) DEFAULT NULL,
  `facilities` text DEFAULT NULL,
  `status` enum('OPEN','FULL','CLOSED','MAINTENANCE') DEFAULT 'OPEN',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `evacuation_centers`
--

INSERT INTO `evacuation_centers` (`id`, `name`, `address`, `city`, `region`, `capacity`, `current_occupancy`, `latitude`, `longitude`, `contact_person`, `contact_phone`, `facilities`, `status`, `created_at`) VALUES
(1, 'Central Community Center', '123 Main Street', NULL, 'Central', 500, 0, NULL, NULL, NULL, NULL, NULL, 'OPEN', '2025-12-10 10:44:29'),
(2, 'North District Shelter', '456 Oak Avenue', NULL, 'Northern', 350, 0, NULL, NULL, NULL, NULL, NULL, 'OPEN', '2025-12-10 10:44:29'),
(3, 'South Regional Facility', '789 Pine Road', NULL, 'Southern', 600, 0, NULL, NULL, NULL, NULL, NULL, 'OPEN', '2025-12-10 10:44:29'),
(4, 'East Emergency Shelter', '321 Elm Street', NULL, 'Eastern', 400, 0, NULL, NULL, NULL, NULL, NULL, 'OPEN', '2025-12-10 10:44:29');

-- --------------------------------------------------------

--
-- Table structure for table `medical_facilities`
--

CREATE TABLE `medical_facilities` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `type` enum('HOSPITAL','CLINIC','FIELD_HOSPITAL','SPECIALTY_CENTER') NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(100) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `bed_capacity` int(11) NOT NULL,
  `available_beds` int(11) DEFAULT NULL,
  `specialties` text DEFAULT NULL,
  `contact_phone` varchar(50) DEFAULT NULL,
  `emergency_services` tinyint(1) DEFAULT 0,
  `trauma_center` tinyint(1) DEFAULT 0,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `status` enum('OPERATIONAL','FULL','LIMITED','CLOSED') DEFAULT 'OPERATIONAL',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medical_facilities`
--

INSERT INTO `medical_facilities` (`id`, `name`, `type`, `address`, `city`, `region`, `bed_capacity`, `available_beds`, `specialties`, `contact_phone`, `emergency_services`, `trauma_center`, `latitude`, `longitude`, `status`, `created_at`) VALUES
(1, 'City General Hospital', 'HOSPITAL', '123 Medical Blvd', NULL, NULL, 250, NULL, 'Full Emergency Care, Surgery, ICU', NULL, 1, 0, NULL, NULL, 'OPERATIONAL', '2025-12-10 10:44:29'),
(2, 'Regional Medical Center', 'HOSPITAL', '456 Health Ave', NULL, NULL, 180, NULL, 'Trauma & Critical Care, Cardiology', NULL, 1, 0, NULL, NULL, 'OPERATIONAL', '2025-12-10 10:44:29'),
(3, 'Community Health Clinic', 'CLINIC', '789 Care Street', NULL, NULL, 50, NULL, 'Urgent Care, Primary Care', NULL, 1, 0, NULL, NULL, 'OPERATIONAL', '2025-12-10 10:44:29'),
(4, 'Emergency Field Hospital', 'FIELD_HOSPITAL', '321 Disaster Response Rd', NULL, NULL, 100, NULL, 'Disaster Response, Mobile Care', NULL, 1, 0, NULL, NULL, 'OPERATIONAL', '2025-12-10 10:44:29');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'aubs', 'dleon', 'aubs@gmail.com', '$2y$10$6.9lABtQaih0kFRjMPpdQOpb4Q41AUpuF5GHGPfSwiQ9BYN6YqyLu', 'admin', '2025-12-01 22:10:23'),
(2, 'ivan', 'macabulos', 'ivandwight3@gmail.com', '$2y$10$dgjO7bcNXWAbL5XmPy3pQOs8Pp0UjVFDj0oeqOznz.Sk9w.sZrcgy', 'user', '2025-12-05 15:18:50'),
(3, 'ronel', 'alforja', 'ronel@example.com', '$2y$10$hYdSStKmt.LNtJjxAP7lKu7TErfD007Mnd795VpHQxIB6LX8pOVaK', 'user', '2025-12-09 08:33:27'),
(4, 'polan', 'polan', 'rodejo770@gmail.com', '$2y$10$xMVwi61JdR6.610HLk86G.ogTC.HZoaeHQOhBuY8YAGuNGuem4VDy', 'user', '2025-12-10 11:42:28'),
(5, 'polan', '123', 'polan123@gmail.com', '$2y$10$dcCz9PrkgPcPB9OFwCA0x.tEIA0FeJMJ4pglSnoR0X3.9myL2WPy.', 'user', '2025-12-10 12:25:28');

-- --------------------------------------------------------

--
-- Table structure for table `user_preferences`
--

CREATE TABLE `user_preferences` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `region` varchar(100) DEFAULT NULL,
  `alert_types` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `alerts`
--
ALTER TABLE `alerts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `disasters`
--
ALTER TABLE `disasters`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `emergency_contacts`
--
ALTER TABLE `emergency_contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `evacuation_centers`
--
ALTER TABLE `evacuation_centers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `medical_facilities`
--
ALTER TABLE `medical_facilities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_preferences`
--
ALTER TABLE `user_preferences`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `alerts`
--
ALTER TABLE `alerts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `disasters`
--
ALTER TABLE `disasters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `emergency_contacts`
--
ALTER TABLE `emergency_contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `evacuation_centers`
--
ALTER TABLE `evacuation_centers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `medical_facilities`
--
ALTER TABLE `medical_facilities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_preferences`
--
ALTER TABLE `user_preferences`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `disasters`
--
ALTER TABLE `disasters`
  ADD CONSTRAINT `disasters_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_preferences`
--
ALTER TABLE `user_preferences`
  ADD CONSTRAINT `user_preferences_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
