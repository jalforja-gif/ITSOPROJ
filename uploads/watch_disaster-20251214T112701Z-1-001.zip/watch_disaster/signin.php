<?php
include('includes/config.php');

// Redirect if already logged in
if(isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

// Process sign in
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];
    
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);
    
    if($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        
        if(password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['first_name'] = $user['first_name'];
            $_SESSION['email'] = $user['email'];
            
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Invalid email or password.";
        }
    } else {
        $error = "Invalid email or password.";
    }
}

$page_title = "Sign In";
include('includes/header.php');
?>

<div class="auth-container">
    <div class="auth-card">
        <div class="auth-header">
            <h1>DisasterWatch</h1>
            <p>Sign in to access your alert preferences</p>
        </div>
        
        <?php if(isset($error)): ?>
            <div style="background: #ffebee; color: #c62828; padding: 1rem; border-radius: 6px; margin-bottom: 1.5rem;">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="email" class="form-label">Email Address *</label>
                <input type="email" id="email" name="email" class="form-control" placeholder="your.email@example.com" required>
            </div>
            
            <div class="form-group">
                <label for="password" class="form-label">Password *</label>
                <input type="password" id="password" name="password" class="form-control" placeholder="Enter your password" required>
            </div>
            
            <button type="submit" class="btn btn-block">Sign In</button>
        </form>
        
        <div class="auth-footer">
            <p><a href="#">Forget password?</a></p>
            <p>Don't have an account? <a href="signup.php">Sign up</a></p>
        </div>
        
        <div style="text-align: center; margin: 2rem 0; color: #666; font-size: 0.9rem;">
            Or continue with
        </div>
        
        <button class="btn btn-block btn-google">
            <i class="fab fa-google"></i> Continue with Google
        </button>
    </div>
</div>

<?php include('includes/footer.php'); ?>